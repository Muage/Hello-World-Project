// import { Link, Route } from 'react-router-dom';
import './App.css';
// import AxiosExample from './component/AxiosExample';
// import NewsList from './component/NewsList';
// import APIComponent from './component2/APIComponent';
import APIExample from './component3/APIExample';
// import RouterExample from './component/RouterExample';

function App() {
	return (
		// <div className="App">
		// 	<RouterExample/>
		// </div>

		// <div className="App">
		// 	<Link to="/users">User List</Link>
		// 	<Route path="/users" component={AxiosExample}/>
		// </div>

		// <div className="App">
		// 	<NewsList/>
		// </div>

		// <div className="App">
		// 	<APIComponent/>
		// </div>

		<div className="App">
			<APIExample/>
		</div>
	);
}

export default App;
