import React, { useCallback, useEffect, useRef, useState } from 'react'
import ProductList from './ProductList';

const ProductPage = ({ history }) => {
    const [query, setQuery] = useState("");
    const refQuery = useRef();

    const onChange = useCallback((e) => {
        setQuery(e.target.value);
        history.push(`/product?query=${query}&page=1`);
    }, [query])

    useEffect(() => {
        refQuery.current.focus();
    }, [])

    return (
        <div>
            <h3>상품검색</h3>
            <input placeholder='검색어' value={query} ref={refQuery}
                onChange={onChange}/>
            <ProductList/>
        </div>
    )
}

export default ProductPage