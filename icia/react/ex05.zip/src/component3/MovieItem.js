import React from 'react'
import Parser from 'html-react-parser'
import './Product.css';

const MovieItem = ({ movie }) => {
    const {title, link, pubDate, director, actor} = movie;
    return (
        <div className='box'>
            <div className='content'>
                <div className='title'>{Parser(title)}</div>
                <div>{pubDate}</div>
                <div>{director}</div>
                <div>{actor}</div>
            </div>
        </div>
    )
}

export default MovieItem