import React from 'react'
import Parser from 'html-react-parser'
import './Product.css';

const ProductItem = ({ product }) => {
    const {title, link, image, lprice} = product;
    return (
        <div className='box'>
            <div className='image'>
                <img src={image}/>
            </div>
            <div className='content'>
                <div className='title'>{Parser(title)}</div>
                <div className='price'>최저가: {lprice}원</div>
                <a href={link}><button>구매하기</button></a>
            </div>
        </div>
    )
}

export default ProductItem