/* global kakao */
import React, { useCallback, useEffect, useState } from 'react'
import { Link, withRouter } from 'react-router-dom'
import qs from 'qs'
import axios from 'axios';
import LocalItem from './LocalItem';

const LocalList = ({ location }) => {
    const search = qs.parse(location.search, {ignoreQueryPrefix: true});
    const query = search.query;
    const page = parseInt(search.page);

    const [locals, setLocals] = useState([]);
    const [loading, setLoading] = useState(false);
    const [is_end, setIs_end] = useState(false);

    const callAPI = useCallback(async() => {
        const url = `https://dapi.kakao.com/v2/local/search/keyword.json?size=5&query=${query}&page=${page}`;
        const config = {
            headers: { Authorization: "KakaoAK 02f3207773863b462be00c93c2734f81" }
        };
        setLoading(true);
        const result = await axios.get(url, config);
        setLoading(false);
        const documents = page === 1 ? result.data.documents : locals.concat(result.data.documents);
        setLocals(documents);
        setIs_end(result.data.meta.is_end);
    }, [query, page])

    useEffect(() => {
        callAPI();
    }, [query, page])

    const callMap = useCallback((x, y) => {
        navigator.geolocation.getCurrentPosition(function(position) {   // GeoLocation을 이용해서 접속 위치를 얻어옵니다
            var lat = position.coords.latitude, // 위도
                lon = position.coords.longitude; // 경도
        });

        let container = document.getElementById('map');
		let options = {
			center: new window.kakao.maps.LatLng(y, x),
			level: 3
		};

    //    // HTML5의 geolocation으로 사용할 수 있는지 확인합니다 
    //     if (navigator.geolocation) {
    //         navigator.geolocation.getCurrentPosition(function(position) {   // GeoLocation을 이용해서 접속 위치를 얻어옵니다
    //             var lat = position.coords.latitude, // 위도
    //                 lon = position.coords.longitude; // 경도

    //             var locPosition = new kakao.maps.LatLng(lat, lon), // 마커가 표시될 위치를 geolocation으로 얻어온 좌표로 생성합니다
    //                 message = '<div style="padding:5px;">여기</div>'; // 인포윈도우에 표시될 내용입니다
            
    //             displayMarker(locPosition, message);    // 마커와 인포윈도우를 표시합니다
    //         });
    //     } else { // HTML5의 GeoLocation을 사용할 수 없을때 마커 표시 위치와 인포윈도우 내용을 설정합니다
    //         var locPosition = new kakao.maps.LatLng(33.450701, 126.570667),    
    //             message = 'geolocation을 사용할수 없어요..'
        
    //             displayMarker(locPosition, message);
    //     }

    //     function displayMarker(locPosition, message) { // 마커와 인포윈도우 표시 함수
    //         var marker = new kakao.maps.Marker({    // 마커 생성
    //             map: map,
    //             position: locPosition
    //         });
    //         var iwContent = message, // 인포윈도우 표시 내용
    //             iwRemoveable = true;

    //         // 인포윈도우를 생성합니다
    //         var infowindow = new kakao.maps.InfoWindow({
    //             content : iwContent,
    //             removable : iwRemoveable
    //         });
            
    //         // 인포윈도우를 마커위에 표시합니다 
    //         infowindow.open(map, marker);
            
    //         // 지도 중심좌표를 접속위치로 변경합니다
    //         map.setCenter(locPosition);      
    //     }

        let map = new window.kakao.maps.Map(container, options);

        let markerPosition = new window.kakao.maps.LatLng(y, x);
        let marker = new kakao.maps.Marker({
            position: markerPosition
        })
        marker.setMap(map);
    })

    if(loading) return(<h3>로딩중입니다...</h3>);

    return (
        <div>
            <h3>검색결과: {query}</h3>
            <div style={{width:500, height:300, border:'1px solid gray'}} id='map'/>
            {locals.map(local => <LocalItem key={local.id} local={local} callMap={callMap}/>)}
            {!is_end && 
                <Link to={`/local?query=${query}&page=${page + 1}`}>
                    <div className='more'>더보기</div>
                </Link>
            }
        </div>
    )
}

export default withRouter(LocalList)