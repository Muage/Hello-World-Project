import React, { useCallback, useEffect, useRef, useState } from 'react'
import MovieList from './MovieList';

const MoviePage = ({ history }) => {
    const [query, setQuery] = useState("");
    const refQuery = useRef();

    const onChange = useCallback((e) => {
        setQuery(e.target.value);
        // history.push(`/movie?query=${query}&page=1`);
    }, [query])

    useEffect(() => {
        history.push(`/movie?query=${query}&page=1`);
        refQuery.current.focus();
    }, [query])

    return (
        <div>
            <h3>영화검색</h3>
            <input placeholder='검색어' value={query} ref={refQuery}
                onChange={onChange}/>
            <MovieList/>
        </div>
    )
}

export default MoviePage