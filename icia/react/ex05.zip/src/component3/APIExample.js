import React from 'react'
import { NavLink, Route } from 'react-router-dom'
import LocalPage from './LocalPage'
import MoviePage from './MoviePage'
import ProductPage from './ProductPage'

const APIExample = () => {
    const activeStyle = {
        background: 'olivedrab',
        color: 'white'
    }

    const style = {
        padding: '10px 20px'
    }

    return (
        <div>
            <NavLink to="/local?query=인천&page=1" style={style} activeStyle={activeStyle}>지역검색</NavLink>
            <NavLink to="/product?query=노트북&page=1" style={style} activeStyle={activeStyle}>상품검색</NavLink>
            <NavLink to="/movie?qeury=아바타&page=1" style={style} activeStyle={activeStyle}>영화검색</NavLink>
            <hr/>
            <Route path="/local" component={LocalPage}/>
            <Route path="/product" component={ProductPage}/>
            <Route path="/movie" component={MoviePage}/>
        </div>
    )
}

export default APIExample