import axios from 'axios';
import React, { useCallback, useEffect, useState } from 'react'
import { Link, withRouter } from 'react-router-dom'
import qs from 'qs'
import ProductItem from './ProductItem';
import './Product.css';

const ProductList = ({ location }) => {
    const search = qs.parse(location.search, {ignoreQueryPrefix: true});
    const query = search.query;
    const page = parseInt(search.page);

    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(false);
    const [is_end, setIs_end] = useState(false);
    const [lastPage, setLastPage] = useState(0);

    const callAPI = useCallback(async() => {
        const url = '/v1/search/shop.json';
        const headers = {
            params: {
                query: query,
                start: (page - 1) * 5 + 1,
                display: 5
            },
            headers: {
                'Content-Type': 'application/json',
                'X-Naver-Client-Id': 'DC8ojH4p4RE2lMhourmV',
                'X-Naver-Client-Secret': '1KTqGCjPFg'
            }
        };
        setLoading(true)
        const result = await axios.get(url, headers);
        setLoading(false)
        setProducts(result.data.items);

        const items = page === 1 ? result.data.items : products.concat(result.data.items);
        setProducts(items);

        const lastPage = Math.ceil(result.data.total / 5);
        setLastPage(lastPage);
        if(page === 3 || page === lastPage) {
            setIs_end(true);
        } else {
            setIs_end(false);
        }
    })

    useEffect(() => {
        callAPI();
    }, [query, page])

    if(loading) return(<h3>로딩중입니다...</h3>);

    return (
        <div>
            <h3>검색결과: {query} ({page} / {lastPage})</h3>
            {products.map(p => <ProductItem key={p.link} product={p}/>)}
            <Link to={`/product?query=${query}&page=${page + 1}`}>
                <div className='more'>더보기</div>
            </Link>
        </div>
    )
}

export default withRouter(ProductList)