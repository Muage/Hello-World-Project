import React, { useCallback, useEffect, useState } from 'react'
import BlogItem from './BlogItem';
import qs from 'qs';
import axios from 'axios';
import { Link } from 'react-router-dom';

const BlogList = ({ match, location }) => {
    const title = match.params.title;
    // console.log('title', title);
    const search = qs.parse(location.search, {ignoreQueryPrefix: true});
    const page = parseInt(search.page);

    const [blogs, setBlogs] = useState();
    const [is_end, setIs_end] = useState(false);

    const callAPI = useCallback(async() => {
        const url = `https://dapi.kakao.com/v2/search/blog?size=5&query=${title}&page=${page}`;
        const config = {
            headers: { Authorization: "KakaoAK 02f3207773863b462be00c93c2734f81" }
        };
        const result = await axios.get(url, config);
        const documents = result.data.documents;
        const newBlogs = page === 1 ? documents : blogs.concat(documents);
        setBlogs(newBlogs);
        setIs_end(result.data.meta.is_end);
    }, [title, page]);

    useEffect(() => {
        callAPI();
    }, [title, page]);

    if(!blogs) return(<h1>데이터를 불러오는 중입니다...</h1>)

    return (
        <div>
            {blogs.map(b => <BlogItem key={b.url} blog={b}/>)}
            {!is_end &&
                <Link to={`/blog/${title}?page=${page + 1}`}>더보기</Link>}
        </div>
    )
}

export default BlogList