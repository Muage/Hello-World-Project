import React from 'react'
import { NavLink, withRouter } from 'react-router-dom'

const categories = [
    {id: 1, title: 'Java'},
    {id: 2, title: 'HTML5'},
    {id: 3, title: 'Node.js'},
    {id: 4, title: 'Database'},
    {id: 5, title: 'JSP&Servlet'},
    {id: 6, title: 'Android'},
    {id: 7, title: 'React'},
    {id: 8, title: 'Spring'}
]

// const Categories = () => {
const Categories = ({ match }) => {
    // console.log('path...', window.location.pathname);
    // const path = window.location.pathname;
    const path = match.path;
    const style = { padding: '15px' }

    const activeStyle = {
        background: 'yellowgreen',
        color: 'white'
    }

    return (
        <div>
            {/* map 사용시 key 값이 필요 */}
            {categories.map(c =>
                <NavLink to={`${path}/${c.title}?page=1`} key={c.id} activeStyle={activeStyle}>
                    <span style={style}>{c.title}</span>
                </NavLink>
            )}
                
        </div>
    )
}

// export default Categories;
export default withRouter(Categories);