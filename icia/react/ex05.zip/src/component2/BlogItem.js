import React from 'react'
import Parser from 'html-react-parser'

const BlogItem = ({ blog }) => {
    const string = `<h4>${blog.title}</h4>`;
    return (
        <div>
            <a href={blog.url}>
                {Parser(string)}
            </a>
        </div>
    )
}

export default BlogItem