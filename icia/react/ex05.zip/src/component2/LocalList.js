import axios from 'axios';
import React, { useCallback, useEffect, useState } from 'react'
import LocalItem from './LocalItem';
import qs from 'qs';
import { Link, withRouter } from 'react-router-dom';
import Map from './Map';

const LocalList = ({ location }) => {
    const [locals, setLocals] = useState();
    const [is_end, setIs_end] = useState(false);
    const [dataX, setDataX] = useState();
    const [dataY, setDataY] = useState();

    const search = qs.parse(location.search, {ignoreQueryPrefix: true});
    const page = parseInt(search.page);
    const query = search.query;

    const callAPI = useCallback(async() => {
        const url = `https://dapi.kakao.com/v2/local/search/keyword.json?size=5&query=${query}&page=${page}`;
        const config = {
            headers: { Authorization: "KakaoAK 02f3207773863b462be00c93c2734f81" }
        };
        const result = await axios.get(url, config);
        const documents = result.data.documents;
        // console.log('데이터:', query);
        setIs_end(result.data.meta.is_end);
        const newLocals = page === 1 ? documents : locals.concat(documents);
        setLocals(newLocals);
    }, [query, page]);

    useEffect(() => {
        callAPI();
    }, [query, page]);

    if(!locals) return ( <h1>데이터를 불러오는 중입니다...</h1> );


    return (
        <div>
            <Map x={dataX} y={dataY}/>
            {locals.map(local => (
                <div key={local.id}>
                    <LocalItem local={local} setDataX={setDataX} setDataY={setDataY}/>
                </div>))}
            <hr/>
            {!is_end &&
                <Link to={`/local?query=${query}&page=${page + 1}`}>
                    <span>더보기</span>
                </Link>}
        </div>
    )
}

export default withRouter(LocalList)