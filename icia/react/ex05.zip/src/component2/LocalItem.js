import { withRouter } from 'react-router-dom';

const LocalItem = ({ local, setDataX, setDataY }) => {
    const {place_name, place_url, id, address_name, phone, x, y} = local;

    const onClick = () => {
        setDataX(x);
        setDataY(y);
    }

    return (
        <div>
            <h4>
                <span>{place_name}: {address_name}: {phone}</span>
                <button onClick={onClick}>위치보기</button>
            </h4>
        </div>
    )
}

export default withRouter(LocalItem)