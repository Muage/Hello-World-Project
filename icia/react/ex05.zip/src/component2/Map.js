/* global kakao */
import React, { useEffect } from 'react'

const Map = ({ x, y }) => {
    // const search = qs.parse(
    //     location.search, {ignoreQueryPrefix: true}
    // );

    useEffect(() => {
        let container = document.getElementById('map');
		let options = {
			center: new window.kakao.maps.LatLng(y, x),
			level: 3
		};
		let map = new window.kakao.maps.Map(container, options);

        let markerPosition = new window.kakao.maps.LatLng(y, x);
        let marker = new kakao.maps.Marker({
            position: markerPosition
        })
        marker.setMap(map);
    }, [x, y])

    return (
        <div id="map" style={{width:'500px', height:'400px'}}></div>
    )
}

export default Map;