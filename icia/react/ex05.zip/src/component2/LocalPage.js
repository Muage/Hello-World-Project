import React, { useState } from 'react'
import LocalList from './LocalList';

const LocalPage = ({ history }) => {
    const [query, setQuery] = useState('인천');

    const onChange = (e) => {
        setQuery(e.target.value);
        history.push(`/local?query=${query}&page=1`)
    }

    return (
        <div>
			<input placeholder='검색어' value={query}
                onChange={onChange}/>
            <hr/>
            <LocalList query={query}/>
        </div>
    )
}

export default LocalPage