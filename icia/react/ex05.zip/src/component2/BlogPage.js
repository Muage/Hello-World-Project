import React from 'react'
import { Route } from 'react-router-dom'
import BlogList from './BlogList'
import Categories from './Categories'

const BlogPage = () => {
    return (
        <div>
            <Categories/>
            <hr/>
            <Route path="/blog/:title" component={BlogList}/>
        </div>
    )
}

export default BlogPage