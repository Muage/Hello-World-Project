import axios from 'axios';
import React, { useEffect, useState } from 'react'

const Todos = ({ match }) => {
    // const id = match.params.id;
    
    const [todos, setTodos] = useState();
    const [id, setId] = useState();

    const callAPI = async() => {
        setId(match.params.id);
        const res = await axios.get('https://jsonplaceholder.typicode.com/todos')
        const newTodos = res.data.filter(todo => todo.userId = id);

        setTodos(newTodos);
    }

    useEffect(() => {
        callAPI();
    })

    if(!todos) return(<h3>데이터를 불러오는 중입니다...</h3>);

    return (
        <div>
            <h2>{id}'s Todo List</h2>
            {todos.map(todo => <h4 key={todo.id}>{todo.id}. {todo.title}</h4>)}
        </div>
    )
}

export default Todos