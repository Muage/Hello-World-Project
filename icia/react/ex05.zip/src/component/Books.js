import axios from 'axios';
import React, { useEffect, useState } from 'react'
import Book from './Book';
import './Book.css';
import qs from 'qs';

const Books = ({ location, page }) => {
    const search = qs.parse(
        location.search, {ignoreQueryPrefix: true}
    );
    const query = search.title;

    const [books, setBooks] = useState();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(false);
    

    const callAPI = async() => {
        try{
            setLoading(true);
            const url = `https://dapi.kakao.com/v3/search/book?target=title&size=5&query=${query}&page=${page}`;
            const config = {
                headers: {Authorization: "KakaoAK 02f3207773863b462be00c93c2734f81"}
            }
            const res = await axios.get(url, config);
            const newBooks = res.data.documents;
            
            setBooks(newBooks);
            setLoading(false);
        } catch(e) {
            setLoading(false);
            setError(e.message);
        }
    }

    useEffect(() => {
        callAPI();
    }, [query, page]);

    if(loading) return(<h3>로딩중입니다...</h3>);

    if(!books) return(<h3>에러발생: {error}</h3>);

    return (
        <div className='books'>
            {books.map(book => <Book key={book.isbn} book={book}/>)}
            {/* <textarea rows={30} cols={100}
                value={JSON.stringify(books, null, 4)}/>
            <button onClick={callAPI}>불러오기</button> */}
        </div>
    )
}

export default Books