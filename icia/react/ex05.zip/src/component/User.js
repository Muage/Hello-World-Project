import React from 'react'
import { NavLink } from 'react-router-dom';

const User = ({ user }) => {
    const {id, name, username, email} = user;
    const style = {
        background: 'skyblue',
        color: 'white'
    }

    console.log('id', id);

    return (
        <div>
            <ul>
                <li>
                    <NavLink to={`/users/${id}`} activeStyle={style}>
                        {id}. {name}({username}, {email})
                    </NavLink>
                </li>
            </ul>
        </div>
    )
}

export default User