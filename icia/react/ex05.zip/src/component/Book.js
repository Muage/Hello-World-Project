import React from 'react'

const Book = ({ book }) => {
    const {thumbnail, title, price, authors, contents, url} = book;

    return (
        <div className='box'>
            <div className='image'>
                <a href={url}><img src={thumbnail} alt=""/></a>
            </div>
            <div className='content'>
                <div className='title'><h4>{title}</h4></div>
                <div className='price'>{price}원</div>
                <div className='authors'>{authors}</div>
                <div className='contents'><p>{contents}</p></div>
            </div>
        </div>
    )
}

export default Book