import React, { useEffect } from 'react'
import { withRouter } from 'react-router-dom'

const WithRouter = ({ match, location, history }) => {
    useEffect(() => {
        const unblock = history.block('뒤로 가시겠습니까?');

        return () => {
            unblock();
        }
    }, [history])

    return (
        <div>
            <h3>location</h3>
            <textarea rows={7} cols={50}
                value={JSON.stringify(location, null, 4)} readOnly/>
            <h4>match</h4>
            <textarea rows={7} cols={50}
                value={JSON.stringify(match, null, 4)} readOnly/>
            <button onClick={() => history.goBack()}>이전페이지</button>
        </div>
    )
}

export default withRouter(WithRouter)