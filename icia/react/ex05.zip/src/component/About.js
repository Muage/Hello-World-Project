import React from 'react'
import qs from 'qs';    // queryString 분석

const About = ({ location }) => {
    // console.log('location', location);

    // const {search} = location;
    // console.log('search', search);

    const query = qs.parse(
        location.search, {ignoreQueryPrefix: true}  // ignoreQueryPrefix: ture -> '?' 무시
    )
    // console.log('query', query);
    
    const page = parseInt(query.page);
    const detail = query.detail ==='true' ? true : false;
    const key = query.key;

    return (
        <div>
            <h1>소개</h1>
            <p>이 프로젝트는 라우터 예제입니다.</p>
            {detail && <p>key: {key}이고, page: {page}입니다.</p>}  {/* &&: detail이 true이면 실행, ||: detail이 null이면 실행 */}
        </div>
    )
}

export default About