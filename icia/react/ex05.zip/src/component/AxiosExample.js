import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Route } from 'react-router-dom';
import Todos from './Todos';
import User from './User';

const AxiosExample = () => {
    const [users, setUsers] = useState();

    const onClick = async() => {    // 비동기 처리
        const res = await axios.get('https://jsonplaceholder.typicode.com/users')
        setUsers(res.data);

        // axios.get('https://jsonplaceholder.typicode.com/users')
        //     .then(res => {
        //         setUsers(res.data);
        //     });
    }

    useEffect(() => {
        onClick();
    }, [])

    if(!users) return(<h1>데이터를 불러오는 중입니다...</h1>);

    return (
        <div>
            <h1>User List</h1>
            {users.map(user => <User key={user.id} user={user}/>)}
            {/* <textarea rows={30} cols={80}
                value={JSON.stringify(users, null, 4)} readOnly/> */}
            <hr/>
            <Route path="/users/:id" component={Todos} exact/>
            <Route path="/users" exact
                render={() => <h3>사용자를 선택해주세요.</h3>}/>
        </div>
    )
}

export default AxiosExample