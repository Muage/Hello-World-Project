import React from 'react'
import { Link } from 'react-router-dom';
import './Category.css';

const categories = [
    {id: 1, title: 'Java'},
    {id: 2, title: 'HTML5'},
    {id: 3, title: 'Node.js'},
    {id: 4, title: 'SQL'},
    {id: 5, title: 'Servlet'},
    {id: 6, title: 'Android'},
    {id: 7, title: 'React'},
    {id: 8, title: 'Spring'}
];

const Categories = () => {
    return (
        <div className='categories'>
            {categories.map(c => 
                <span className='category' key={c.id}>
                    <Link to={`/?title=${c.title}`}>{c.title}</Link>
                </span>
            )}
        </div>
    );
}

export default Categories