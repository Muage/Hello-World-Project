import axios from 'axios';
import React, { useState } from 'react'

const ReplyInsert = ({ bno, callAPI }) => {
    const [content, setContent] = useState('');

    const onSubmit = async(e) => {
        e.preventDefault();
        if(!window.confirm('댓글을 등록하시겠습니까?')) return;
        await axios.post('/reply/insert', { bno: bno, content: content });
        callAPI();
        setContent('');
    }

    return (
        <form onSubmit={onSubmit}>
            <input
                placeholder='댓글 입력'
                size={80}
                onChange={(e) => setContent(e.target.value)}/>
            <button type='submit'>등록</button>
        </form>
    )
}

export default ReplyInsert