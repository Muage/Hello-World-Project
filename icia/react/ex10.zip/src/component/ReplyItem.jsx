import axios from 'axios';
import React from 'react'

const ReplyItem = ({ reply, callAPI }) => {
    const {rno, content, replyDate} = reply;

    const onClickDelete = async(rno) => {
        if(!window.confirm(`${rno}번 댓글을 삭제하시겠습니까?`)) return;
        await axios.post(`/reply/delete/${rno}`);
        alert('삭제되었습니다.');
        callAPI();
    }

    return (
        <tr>
            <td width={50}>{rno}</td>
            <td width={500}>{content}</td>
            <td width={100}>{replyDate}</td>
            <td><button onClick={() => onClickDelete(rno)}>삭제</button></td>
        </tr>
    )
}

export default ReplyItem