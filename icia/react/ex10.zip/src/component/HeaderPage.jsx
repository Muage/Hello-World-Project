import React from 'react'
import { Link, withRouter } from 'react-router-dom'

const HeaderPage = ({ history }) => {
    const onClickLogout = (e) => {
        e.preventDefault();

        sessionStorage.clear();
        history.push('/');
    }

    return (
        <div>
            <div className='main_menu'>
				<Link to='/'>홈</Link>
				<Link to='/board/list'>게시판관리</Link>
                <Link to='/message'>메시지함</Link>
                {sessionStorage.getItem("uid") ?
                    <>
                    <a
                        href='#'
                        style={{float: "right"}}
                        onClick={onClickLogout}>
                            로그아웃
                    </a>
                    <span style={{float: "right", marginRight: "20px", fontSize: "1.2rem"}}>
                        {sessionStorage.getItem("uid")}
                    </span> 
                    </> :
				    <Link to='/login' style={{float: "right"}}>로그인</Link>
                }
			</div>
            <hr/>
        </div>
    )
}

export default withRouter(HeaderPage)