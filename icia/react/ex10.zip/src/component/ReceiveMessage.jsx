import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Table } from 'react-bootstrap';
import ReceiveItem from './ReceiveItem';

const ReceiveMessage = ({ setUser }) => {
    const uid = sessionStorage.getItem("uid");

    const [list, setList] = useState([]);
    

    const callAPI = async() => {
        const result = await axios.get(`/message/receive/${uid}`);
        setList(result.data);
    }

    useEffect(() => {
        callAPI();
    }, [])

    if(!list) return <h1>Loading...</h1>

    return (
        <div>
            <Table className="my-5">
                <thead>
                    <tr>
                        <td>No.</td>
                        <td>보낸이</td>
                        <td>보낸날짜</td>
                        <td>읽은날짜</td>
                        <td>보기</td>
                    </tr>
                </thead>
                <tbody>
                {list.map(message =>
                    <ReceiveItem
                        key={message.mid}
                        message={message}
                        callAPI={callAPI}
                        setUser={setUser}/>
                )}
                </tbody>
            </Table>
        </div>
    )
}

export default ReceiveMessage