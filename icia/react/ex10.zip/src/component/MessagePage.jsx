import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link, Route } from 'react-router-dom'
import { UserContext } from '../context/UserContext'
import HeaderPage from './HeaderPage'
import ReceiveMessage from './ReceiveMessage'
import SendMessage from './SendMessage'

const MessagePage = () => {
    const uid = sessionStorage.getItem("uid");

    const [user, setUser] = useState({
        uname: "",
        point: 0,
        receivecnt: 0,
        sendcnt: 0
    });
    const {uname, point, receivecnt, sendcnt} = user;

    const callAPIUser = async() => {
        const result = await axios.get(`/user/read/${uid}`);
        setUser(result.data);
    }

    useEffect(() => {
        callAPIUser();
    }, [])


    return (
        <UserContext.Provider value={{callAPIUser}}>
            <div>
                <HeaderPage/>
                <div className='sub_menu'>
                    <Link to='/message/receive'>받은메일함 ({receivecnt})</Link>
                    <Link to='/message/send'>보낸메일함 ({sendcnt})</Link>
                    <span>포인트: {point}</span>
                </div>
                <hr/>
                <Route path='/message/receive' component={ReceiveMessage}/>
                <Route path='/message/send' component={SendMessage}/>
            </div>
        </UserContext.Provider>
    )
}

export default MessagePage