import axios from 'axios';
import React, { useContext, useEffect, useState } from 'react'
import { Button, Form, Modal, Table } from 'react-bootstrap';
import { UserContext } from '../context/UserContext';
import SendItem from './SendItem';

const SendMessage = () => {
    const {callAPIUser} = useContext(UserContext);

    const uid = sessionStorage.getItem("uid");

    const [list, setList] = useState([]);
    const [users, setUsers] = useState([]);
    const [message, setMessage] = useState("");
    const [receiver, setReceiver] = useState("");

    // modal
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const callAPI = async() => {
        const result = await axios.get(`/message/send/${uid}`);
        setList(result.data);
    }

    const callUsers = async() => {
        const result = await axios.get('/user/list');
        setUsers(result.data);
    }

    const onClickSend = async() => {
        if(!window.confirm(`${uid}가 ${receiver}에게 ${message}를 전송하시겠습니까?`)) return;

        await axios.post('/message/insert/', { sender: uid, receiver: receiver, message: message });
        handleClose();
        setMessage("");
        callAPIUser();
        callAPI();
    }

    useEffect(() => {
        callAPI();
        callUsers();
    }, [])

    if(!list || !users) return <h1>Loading...</h1>

    return (
        <div>
            <Button variand="primary" onClick={handleShow} className="my-3">
                메시지 작성
            </Button>
            <Table className='my-2'>
                <thead>
                    <tr>
                        <td>No.</td>
                        <td>받은이</td>
                        <td>보낸날짜</td>
                        <td>읽은날짜</td>
                        <td>보기</td>
                    </tr>
                </thead>
                <tbody>
                    {list.map(msg =>
                        <SendItem key={msg.mid} msg={msg}/>
                    )}
                </tbody>
            </Table>
            
            <Modal show={show} onHide={handleClose} animation={false}>
                <Modal.Header closeButton>
                    <Modal.Title>메시지입력</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form.Select className="mb-2"
                        onChange={(e) => setReceiver(e.target.value)}>
                        <option>받을 이를 선택해주세요.</option>
                        {users.map(user =>
                            <option
                                key={user.uid}
                                value={user.uid}>
                                {user.uname} ({user.uid})
                            </option>  
                        )}
                    </Form.Select>
                    <Form.Control
                        value={message}
                        as="textarea" rows={5}
                        placeholder="메시지 내용을 입력하세요."
                        onChange={(e) => setMessage(e.target.value)}/>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        취소
                    </Button>
                    <Button variant="primary" onClick={onClickSend}>
                        전송
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default SendMessage