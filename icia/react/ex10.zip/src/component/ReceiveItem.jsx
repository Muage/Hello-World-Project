import axios from 'axios';
import React, { useContext, useState } from 'react'
import { Button, Modal } from 'react-bootstrap';
import { UserContext } from '../context/UserContext';

const ReceiveItem = ({ message, callAPI }) => {
    const {callAPIUser} = useContext(UserContext);
    const { mid, sender, uname, readDate, sendDate } = message;

    const [newMessage, setNewMessage] = useState("");

    // modal
    const [show, setShow] = useState(false);
    const handleClose = async() => {
        setShow(false);
        callAPI();
        callAPIUser();
    }

    const onClickView = async() => {
        const result = await axios.get(`/message/read/${mid}`)
        setNewMessage(result.data.message);
        setShow(true);
    }

    return (
        <>
            <tr style={{ color: !readDate && "navy" }}>
                <td>{mid}</td>
                <td>{sender} ({uname})</td>
                <td>{sendDate}</td>
                <td>{readDate}</td>
                <td>
                    <Button variant="primary" onClick={onClickView}>보기</Button>
                </td>
            </tr>
            <Modal show={show} onHide={handleClose} animation={false}>
                <Modal.Header closeButton>
                    <Modal.Title>메시지확인</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {newMessage}
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" onClick={handleClose}>
                        확인
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

export default ReceiveItem