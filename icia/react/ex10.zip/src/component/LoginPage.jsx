import axios from 'axios';
import React, { useState } from 'react'
import { Alert, Button, Card, Form } from 'react-bootstrap'
import HeaderPage from './HeaderPage';

const LoginPage = ({ history }) => {
    const [message, setMessage] = useState('');
    const [form, setForm] = useState({
        uid: "",
        upass: ""
    });
    const {uid, upass} = form;

    const onSubmit = async(e) => {
        e.preventDefault();

        const result = await axios.get(`/user/read/${uid}`);

        if(!result.data) {
            setMessage("해당 아이디가 존재하지 않습니다.");
        } else if(result.data.upass !== upass) {
            setMessage("비밀번호가 일치하지 않습니다.");
        } else {
            setMessage("");
            sessionStorage.setItem("uid", uid);
            history.push('/');
        }
    }

    const onChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        })
    }

    return (
        <>
        <HeaderPage/>
        <Card style={{width: "50%"}}>
            <Form className="p-3" onSubmit={onSubmit}>
                <Form.Control
                    value={uid}
                    name="uid"
                    className="my-3"
                    placeholder="User id"
                    onChange={onChange}/>
                <Form.Control
                    value={upass}
                    name="upass"
                    className="my-3"
                    type="password"
                    placeholder="Password"
                    onChange={onChange}/>
                <Button type="submit">로그인</Button>
            </Form>
            {message &&
                <Alert key="primary" variant="primary" className="m-3">
                    {message}
                </Alert>
            }
        </Card>
        </>
    )
}

export default LoginPage