import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, Switch } from 'react-router-dom';
import BoardPage from './component/BoardPage';
import HomePage from './component/HomePage';
import LoginPage from './component/LoginPage';
import MessagePage from './component/MessagePage';

function App() {
	return (
		<div className="App">
			<Switch>
				<Route path='/' component={HomePage} exact/>
				<Route path='/board' component={BoardPage}/>
				<Route path='/login' component={LoginPage}/>
				<Route path='/message' component={MessagePage}/>
			</Switch>
		</div>
	);
}

export default App;
