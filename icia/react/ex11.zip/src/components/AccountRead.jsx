import axios from 'axios';
import React, { useContext, useEffect, useState } from 'react'
import { Button, Card, Col, Form, Modal, Row, Table } from 'react-bootstrap';
import { AccountContext } from '../context/AccountContext';
import TradeItem from './TradeItem';

const AccountRead = ({ match }) => {
    const accounts = useContext(AccountContext);
    const ano = match.params.ano;

    const [account, setAccount] = useState("");
    const {aname, openDate, balance, fbalance} = account;

    const [trades, setTrades] = useState([]);
    const [trade, setTrade] = useState({
        ano: ano,
        tno: "",
        amount: ""
    });

    const callAPIAccount = async() => {
        const result = await axios.get(`/api/account/read/${ano}`);
        setAccount(result.data);
    }

    const callTrades = async() => {
        const result = await axios.get(`/api/trade/list/${ano}`);
        setTrades(result.data);
    }

    const onSubmit = async() => {
        if(trade.amount > balance) {
            alert("잔액이 부족합니다.")
            return;
        }

        if(!window.confirm(`${trade.ano}가 ${trade.tno}에게 ${trade.amount}원을 이체하시겠습니까?`)) return;

        await axios.post('/api/trade/', trade);
        handleClose();
        setTrade({
            ano: ano,
            tno: "",
            amount: ""
        });
        callAPIAccount();
        callTrades();
    }

    const onChange = (e) => {
        setTrade({
            ...trade,
            [e.target.name]: e.target.value
        })
    }

    //modal
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    useEffect(() => {
        callAPIAccount();
        callTrades();
    }, [])

    if (!account || !trades || !accounts) return <h1>Loading...</h1>

    return (
        <div>
            <Card className="my-5 p-3">
                <Row>
                    <Col>계좌번호: {ano}</Col>
                    <Col>계좌주명: {aname}</Col>
                    <Col md={4}>개설일: {openDate}</Col>
                    <Col>잔액: {fbalance}</Col>
                </Row>
            </Card>
            <Button variant="dark" onClick={handleShow}>
                계좌이체
            </Button>
            <hr/>
            <Table
                striped>
                <thead>
                    <tr>
                        <td>계좌번호</td>
                        <td>거래일</td>
                        <td>입금 / 출금</td>
                        <td>입출금액(원)</td>
                    </tr>
                </thead>
                <tbody>
                    {trades.map(trade =>
                        <TradeItem key={trade.id} trade={trade} />
                    )}
                </tbody>
            </Table>

            {/* 계좌이체 */}
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>계좌이체</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form.Select
                        name="tno"
                        value={trade.tno}
                        className="my-3"
                        onChange={onChange}>
                        <option>계좌를 선택하세요</option>
                        {accounts.map(account =>
                            <option key={account.ano} value={account.ano}>
                                {account.ano} ({account.aname})
                            </option>
                        )}
                    </Form.Select>
                    <Form.Control
                        name="amount"
                        value={trade.amount}
                        placeholder="이체금액"
                        type="number"
                        step={100}
                        onChange={onChange}/>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        취소
                    </Button>
                    <Button
                        variant="primary"
                        onClick={onSubmit}>
                            이체
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default AccountRead