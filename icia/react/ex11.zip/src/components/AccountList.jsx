import { useContext } from 'react';
import { Table } from 'react-bootstrap';
import { AccountContext } from '../context/AccountContext';
import AccountItem from './AccountItem';

const AccountList = () => {
    const {accounts} = useContext(AccountContext);

    return (
        <div>
            <Table
                className="my-5"
                striped>
                <thead>
                    <tr>
                        <td>No.</td>
                        <td>성명</td>
                        <td>개설일</td>
                        <td>잔액(원)</td>
                        <td>거래내역</td>
                    </tr>
                </thead>
                <tbody>
                    {accounts.map(account =>
                        <AccountItem key={account.ano} account={account}/>
                    )}
                </tbody>
            </Table>
        </div>
    )
}

export default AccountList