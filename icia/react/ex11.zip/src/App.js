import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, Switch } from 'react-router-dom';
import AccountPage from './components/AccountPage';
import HomePage from './components/HomePage';

function App() {
	return (
		<div className="App">
			<Switch>
				<Route path='/' component={HomePage} exact/>
				<Route path='/account' component={AccountPage}/>
			</Switch>
		</div>
	);
}

export default App;
