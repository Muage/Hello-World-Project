import axios from 'axios';
import React, { useCallback, useEffect, useState } from 'react'
import BestItem from './BestItem';

const BestList = () => {
    const [products, setProducts] = useState();
    const [items, setItems] = useState([]);

    const onSingle = useCallback((id, checked) => {
        if(checked) {
            setItems(items.concat(id));
        } else {
            setItems(items.filter(item => item !== id));
        }
    }, [items])

    const onAll = (checked) => {
        if(checked) {
            const all = [];
            products.forEach(p => all.push(p.id));
            setItems(all);
        } else {
            setItems([]);
        }
    }

    const onClickToggle = async(show) => {
        const message = show === 1 ? 'show' : 'hide';
        
        if(items.length === 0) {
            alert(`${message} 할 항목을 선택해주세요.`);
            return;
        }

        if(!window.confirm(`${items.length}개 항목을 ${message} 하시겠습니까?`)) return;

        for(let i = 0; i < items.length; i++) {
            const data = { id: items[i], isShow: show };
            await axios.post(`/best/toggle`, data);
        }
        callAPI();
        setItems([]);
    }

    const callAPI = async() => {
        const result = await axios.get('/best/list');
        setProducts(result.data);
    }

    useEffect(() => {
        callAPI();
    }, [])

    if(!products) return <h1>데이터를 불러오는 중입니다...</h1>

    return (
        <div>
            <h1>Best Product List</h1>
            <div>
                <button onClick={() => onClickToggle(1)}>show</button>
                <button onClick={() => onClickToggle(0)}>hide</button>
            </div>
            <table>
                <tbody>
                    <tr>
                        <td>
                            <input type="checkbox"
                                onChange={(e) => onAll(e.target.checked)}
                                checked={products.length === items.length && true}/>
                        </td>
                        <td width={30}>ID</td>
                        <td width={400}>Title</td>
                        <td width={300}>Category</td>
                        <td width={100}>Price</td>
                        <td width={30}>Show</td>
                    </tr>
                    {products.map(p =>
                        <tr key={p.id} className={!p.isShow ? 'linethrough row' : 'row'}>
                            <BestItem product={p} items={items}
                                onSingle={onSingle}/>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    )
}

export default BestList