import axios from 'axios';
import React, { useState } from 'react'

const BestInsert = ({ history }) => {
    const [image, setImage] = useState('https://dummyimage.com/300x200');
    const [form, setForm] = useState({
        title: '',
        category: 'Play Station',
        price: '',
        file: null,
        fileName: ''
    });

    const {title, category, price, file, fileName} = form;

    // 미리보기
    const onChangeFile = (e) => {
        const reader = new FileReader();
        
        reader.onload = (e) => {
            setImage(e.target.result);
        }
        reader.readAsDataURL(e.target.files[0]);

        setForm({
            ...form,
            file: e.target.files[0],
            fileName: e.target.value
        });
    }

    // form Data 값 변경
    const onChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    }

    // Click Register button
    const onSubmit = async(e) => {
        e.preventDefault();
        if(title === '' || price === '' || fileName === '') {
            alert('모든 항목을 입력해주세요.');
            return;
        }
        console.log('form.....', form);

        if(!window.confirm('새로운 상품을 등록하시겠습니까?')) return;
        const formData = new FormData();
        formData.append('image', file);
        formData.append('title', title);
        formData.append('category', category);
        formData.append('price', price);
        const config = {
            headers: {'content-type': 'multipart/form-data'}
        };
        await axios.post('/best/insert', formData, config);
        history.push('/best/list');
    }

    return (
        <div className='form_best'>
            <h1>Best Register</h1>
            <form onSubmit={onSubmit}>
                <input onChange={onChange} value={title} name='title' placeholder='Title'/>
                <select onChange={onChange} value={category} name='category'>
                    <option>Nintendo Switch</option>
                    <option>Play Station</option>
                    <option>XBox</option>
                </select>
                <input onChange={onChange} value={price} name='price' placeholder='Price'/>
                <img src={image} width={300}/>
                <input name='file' type="file" onChange={onChangeFile}/>
                <button>Best Register</button>
            </form>
        </div>
    )
}

export default BestInsert