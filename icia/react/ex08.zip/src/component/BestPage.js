import React from 'react'
import { Link, Route } from 'react-router-dom'
import BestInsert from './BestInsert'
import BestList from './BestList'
import BestRead from './BestRead'

const BestPage = () => {
    return (
        <div>
            <div className='sub_menu'>
                <Link to="/best/list">Best List</Link>
                <Link to="/best/insert">Best Insert</Link>
            </div>
            <Route path="/best/list" component={BestList}/>
            <Route path="/best/insert" component={BestInsert}/>
            <Route path="/best/read/:id" component={BestRead}/>
        </div>
    )
}

export default BestPage