import React, { useEffect, useRef, useState } from 'react'

const Info = () => {
    const [name, setName] = useState('');
    const[nickname, setNickname] = useState('');

    const refNumber = useRef(0);

    useEffect(() => {
        refNumber.current = refNumber.current + 1;
        console.log('렌더링 확인...' + refNumber.current)

        return () => {  // 뒷정리 함수 reRendering 전에 실행
            console.log('Clean Up.....', name)
        }
    })

    return (
        <div>
            <input value={name} type="text" placeholder="이름"
                onChange={(e) => setName(e.target.value)}/>
            <input value={nickname} type="text" placeholder="별명"
                onChange={(e) => setNickname(e.target.value)}/>
            <hr/>
            <h3>이름: {name}</h3>
            <h3>별명: {nickname}</h3>
        </div>
    )
}

export default Info