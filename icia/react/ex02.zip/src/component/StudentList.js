import React, { useRef, useState } from 'react'
import Student from './Student';
import StudentInsert from './StudentInsert';

const StudentList = () => {
    const refNo = useRef(4);

    const [data, setData] = useState([
        { id: 1, sname: '홍길동', address: '인천시 미추홀구 문학동', tel: '010-0000-1111' },
        { id: 2, sname: '심청이', address: '서울시 송파구 잠실동', tel: '010-0000-2222' },
        { id: 3, sname: '강감찬', address: '서울시 구로구 고척동', tel: '010-0000-3333' }
    ]);

    const onDelete = (id) => {
        if(!window.confirm(`${id}번 학생을 삭제하시겠습니까?`)) return;
        const newData = data.filter(s => s.id !== id);
        setData(newData);
    }

    const onInsert = (s) => {
        if(!window.confirm(`${refNo.current}번 학생을 등록하시겠습니까?`)) return;
        const newData = data.concat({
            id: refNo.current,
            sname: s.sname,
            address: s.address,
            tel: s.tel
        });
        setData(newData);
        refNo.current = refNo.current + 1;
    }

    return (
        <div>
            <StudentInsert onInsert={onInsert} id={refNo.current}/>
            <br/>
            <table width={600}>
                {/* <Student sname="홍길동" tel="010-0000-1111" address="인천시 미추홀구 문학동"/>
                <hr/>
                <Student sname="심청이" tel="010-0000-2222" address="서울시 송파구 잠실동"/> */}
                {data.map(s =>
                    <Student key={s.id}
                        id={s.id}
                        sname={s.sname}
                        address={s.address}
                        tel={s.tel}
                        onDelete={onDelete}
                    />)}
            </table>
        </div>
    )
}

export default StudentList