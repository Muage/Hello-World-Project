import React, { useEffect, useState } from 'react'
import Comment from './Comment';

const Post = (props) => {
    const { id, title, body } = props.post;

    const [comments, setComments] = useState();
    const [show, setShow] = useState(false);

    const callAPI = () => {
        fetch(`https://jsonplaceholder.typicode.com/comments?postId=${id}`)
            .then(response => response.json())
            .then(json => {
                console.log(id, json.length);
                setComments(json)
            });
    }

    useEffect(() => {
        callAPI();
    }, [props.post]);

    return (
        <div style={{ textAlign: 'left', width: 500, margin: '0 auto' }}>
            <span style={{ fontWeight: 'bold' }}>{id} </span>
            <span>{title}</span>
            <br/>
            <div style={{ color: '#777777', borderBottom: '1px dotted #777777' }}>
                {body}
                <br />
                <button onClick={() => setShow(!show)}>
                    {show ? '댓글숨기기' : '댓글보이기'}
                </button>
                {show && comments.map(c => <Comment key={c.id} comment={c}/>)}
            </div>
        </div>
    )
}

export default Post