import React, { useState } from 'react'
import Post from './Post';
import Todo from './Todo';

const User = (props) => {
    const {id, name, username, email, address} = props.user;

    const [todos, setTodos] = useState();
    const [posts, setPosts] = useState();
    const [showTodo, setShowTodo] = useState(false);
    const [showPost, setShowPost] = useState(false);

    let newAddress = address.street + ' ' + address.suite + ' ' + address.city + ' (' + address.zipcode + ')';

    const callTodoAPI = () => {
        fetch('https://jsonplaceholder.typicode.com/todos')
            .then(response => response.json())
            .then(json => {
                // console.log(id, json.length);
                const newTodos = json.filter(todo => todo.userId === id);
                setTodos(newTodos);
                setShowTodo(!showTodo);
            });
    }

    const callPostAPI = () => {
        fetch('https://jsonplaceholder.typicode.com/posts')
            .then(response => response.json())
            .then(json => {
                // console.log(id, json.length);
                const newPosts = json.filter(post => post.userId === id);
                setPosts(newPosts);
                setShowPost(!showPost);
            });
    }

    return (
        <div style={{ margin: '20px auto', width: 600, borderBottom: '1px solid #BBBBBB'}}>
            <div>[{id}] {name}({username})</div>
            <div>{email}</div>
            <div>{newAddress}</div>
            <button style={{margin: '10px'}}
                onClick={callTodoAPI}>
                Todo List
            </button>
            <button style={{margin: '10px'}}
                onClick={callPostAPI}>
                Post List
            </button>
            {showTodo && 
                <div>
                    {todos && todos.map(t => <Todo key={t.id} todo={t}/>)}
                </div>
            }
            {showPost && 
                <div>
                    {posts && posts.map(p => <Post key={p.id} post={p}/>)}
                </div>
            }
        </div>
    )
}

export default User