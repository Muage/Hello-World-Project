import React, { useRef, useState } from 'react'

const StudentInsert = ({onInsert, no}) => {
    const refName = useRef();

    const [form, setForm] = useState({
        id: no,
        sname: '무기명',
        address: '수원시 장안구 조원동',
        tel: '010-0000-4444'
    })

    // console.log('렌더링확인.....', form);

    const {id, sname, address, tel} = form;

    const onChangeForm = (e) => {
        const newForm = {
            ...form,
            [e.target.name]: e.target.value
        }
        setForm(newForm);
    }

    const onInsertForm = () => {
        onInsert(form);
        refName.current.focus();
    }

    return (
        <div>
            <input ref={refName} value={sname} name="sname" type="text" placeholder="이름" size={10}
                onChange={onChangeForm}/>
            <input value={address} name="address" type="text" placeholder="주소" size={30}
                onChange={onChangeForm}/>
            <input value={tel} name="tel" type="text" placeholder="전화번호" size={19}
                onChange={onChangeForm}/>
            <button onClick={onInsertForm}>등록</button>
        </div>
    )
}

export default StudentInsert