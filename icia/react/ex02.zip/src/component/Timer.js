import React, { useEffect, useRef } from 'react'

const Timer = () => {
    const number = useRef(0);

    useEffect(() => {
        const timer = setInterval(() => {
            number.current = number.current + 1;
            console.log('타이머가 돌아가는 중...', number.current);
        }, 1000);

        return () => {
            clearInterval(timer);
            console.log('타이머가 중지되었습니다.');
        }
    }, []);

    return (
        <div>
            <span>{number.current}초</span>
        </div>
    )
}

export default Timer