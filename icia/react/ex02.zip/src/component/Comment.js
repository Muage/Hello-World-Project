import React from 'react'

const Comment = (props) => {
    const {id, name, email, body} = props.comment;

    return (
        <div>
            <p style={{fontSize: 13}}>[{id}] {name}({email})</p>
            <p style={{fontSize: 13}}>{body}</p>
        </div>
    )
}

export default Comment