import React, { useRef, useState } from 'react'

const UseRefSample = () => {
    // console.log('렌더링확인.....');
    
    const [count, setCount] = useState(0);

    const refCount = useRef(0);

    let varCount = 0;

    const onClickRef = () => {
        refCount.current = refCount.current + 1;
        console.log('refCount...' + refCount.current);
    }

    const onClickVar = () => {
        varCount = varCount + 1;
        console.log('varCount...' + varCount);
    }

    return (
        <div>
            <p>State 변수: {count}</p>
            <p>Ref 변수: {refCount.current}</p>
            <p>var 변수: {varCount}</p>

            <button onClick={() => setCount(count + 1)}>
                State 변수 증가
            </button>
            <button onClick={onClickRef}>
                Ref 변수 증가
            </button>
            <button onClick={onClickVar}>
                var 변수 증가
            </button>
        </div>
    )
}

export default UseRefSample