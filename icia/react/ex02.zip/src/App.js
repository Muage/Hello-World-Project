import { useState } from 'react';
import './App.css';
import Info from './component/Info';
import Posts from './component/Posts';
import StudentList from './component/StudentList';
import Timer from './component/Timer';
import Todos from './component/Todos';
import UseRefSample from './component/UseRefSample';
import UseRefSample1 from './component/UseRefSample1';
import Users from './component/Users';

// function App() {
const App = () => {
    // const name = '홍길동';  // const는 재선언, 재할당 불가능
    // name = '심청이';    // 따라서 변수 변경 시 오류

    let name  = '홍길동';   // let은 재선언 불가능, 재할당 가능
    name = '심청이';

    const [show, setShow] = useState(false);
    const [item, setItem] = useState(1);

    return (
        <div className="App"> {/* JSX 주석 */}
            <h1>리액트 시작 ({name} - {100 + 200})</h1>

            <br/><hr/><br/>

            <h1>학생목록</h1>
            <StudentList/>

            <br/><hr/><br/>

            <UseRefSample/>

            <br/><hr/><br/>

            <UseRefSample1/>

            <br/><hr/><br/>

            {show && <Info/>}
            <button onClick={() => setShow(!show)}>
                {show ? '숨기기' : '보이기'}
            </button>

            <br/><hr/><br/>

            {show && <Timer/>}
            <button onClick={() => setShow(!show)}>
                {show ? '숨기기' : '보이기'}
            </button>
            
            <br/><hr/><br/>

            <div>
                <span className='item'
                    onClick={() => setItem(1)}>
                    Todo List
                </span>
                <span className='item'
                    onClick={() => setItem(2)}>
                    Post List
                </span>
                <span className='item'
                    onClick={() => setItem(3)}>
                    User List
                </span>
            </div>
            {item === 1 ? <Todos/> : item === 2 ? <Posts/> : <Users/>}
        </div>
    );
}

export default App;