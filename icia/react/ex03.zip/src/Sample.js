// import './App.css';
import TodoTemplate from './component/TodoTemplate';
// import Users from './component/Users';
// import Students from './component/Students';
import TodoInsert from './component/TodoInsert';
import TodoList from './component/TodoList';
import { useRef, useState } from 'react';

// var var1 = 'var 변수'; // 파일 전체에서 사용하는 경우

// const print = () => {
//     const const1 = 'const 변수';    // 선언된 함수 안에서만 사용하는 경우

//     console.log('var1: ' + var1);
// }

const Sample = () => {	// 화살표 함수로 정의
    // console.log('var1: ' + var1);
    // const name = '리액트';

    const nextId = useRef(5);

    const [todos, setTodos] = useState([
        { id: 1, text: '리액트의 기초 알아보기', checked: true },
        { id: 2, text: '컴포넌트 스타일링해 보기', checked: true },
        { id: 3, text: '일정 관리 앱 만들어 보기', checked: false },
        { id: 4, text: '리액트 Hook 알아보기', checked: false }
    ]);

    const onInsert = (text) => {
        if(!window.confirm(`${nextId.current}번째 할 일을 등록하시겠습니까?`)) return;

        const todo = {
            id: nextId.current, //useRef가 Object로 생성되어 current 사용
            text,
            checked: false
        }
        setTodos(todos.concat(todo));
        nextId.current = nextId.current + 1;
    }

    const onDelete = (id) => {
        if(!window.confirm(`${id}번째 할 일을 삭제하시겠습니까?`)) return;
        setTodos(todos.filter(todo => id !== todo.id))
    }

    const onToggle = (id) => {
        const newTodos = todos.map(todo =>
            id === todo.id ?
            {...todo, checked:!todo.checked} :
            todo
        )
        setTodos(newTodos);
    }

    return (
		// Practice 1
        // <div className="App">
        //     <h1>{name === 'react' ? '리액트' : 'react'} 안녕!</h1>
        //     <h1>{name && 'react'} 안녕!</h1>	{/* name이 true이면 'react' 출력 */}
		// 	<h1>{name || 'react'} 안녕!</h1>	{/* name 값이 있으면 name, 없으면 'react' 출력 */}
        // </div>

        // Practice 2
		// <div className="App">
		// 	<Students/>
		// </div>

        // Practice 3
        // <div className="App">
		// 	<Users/>
		// </div>

        <TodoTemplate>
            <TodoInsert onInsert={onInsert}/>
            <TodoList todos={todos} onDelete={onDelete} onToggle={onToggle}/>
        </TodoTemplate>
    );
}

export default Sample;
