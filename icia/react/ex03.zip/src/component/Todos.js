import React, { useEffect, useState } from 'react'

const Todos = ({ id, name }) => {
    const [todos, setTodos] = useState();

    const callAPI = () => {
        fetch('https://jsonplaceholder.typicode.com/todos')
            .then(response => response.json())
            .then(json => {
                const newTodos = json.filter(todo => id === todo.userId);
                setTodos(newTodos);
                // console.log(todos.length);
            });
    }

    useEffect(() => {
        callAPI();
    }, [id]);

    if(!todos) return(<h1>데이터를 불러오는 중입니다...</h1>)

    return (
        <div>
            <h1>{name}'s Todo List</h1>
            {todos.map(t => <h5 key={t.id}>{t.id}. {t.title}</h5>)}
        </div>
    )
}

export default Todos