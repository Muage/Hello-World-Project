import React, { useState } from 'react'

const StudentInsert = ({onInsert}) => { //Students의 <StudentInsert onInsert/>를 통해 받음
    const [form, setForm] = useState({
        name: '',
        tel: '010',
        add: '인천시 미추홀구 문학동'
    });

    const {name, tel, add} = form;

    const onChangeForm = (e) => {   // input 내용 변경 함수
        const newForm = {
            ...form,
            [e.target.name]: e.target.value
        }
        setForm(newForm);
    }

    const onInsertStudent = () => { // 입력 후 input clear 함수
        onInsert(form);
        setForm({
            name: '',
            tel: '010',
            add: '인천시 미추홀구 문학동'
        })
    }

    return (
        <div>
            <h1>학생등록</h1>
            <input name="name" value={name} placeholder="이름"
                onChange={onChangeForm}/><br/>
            <input name="tel" value={tel} placeholder="전화"
                onChange={onChangeForm}/><br/>
            <input name="add" value={add} placeholder="주소"
                onChange={onChangeForm}/><br/>
            <button onClick={onInsertStudent}>등록</button>
        </div>
    )
}

export default StudentInsert