import React from 'react'

const Home = () => {
    return (
        <div>
            <h1>홈</h1>
            <p>가장 먼저 보여주는 페이지 입니다.</p>
        </div>
    )
}

export default Home