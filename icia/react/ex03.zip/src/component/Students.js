import React, { useRef, useState } from 'react'
import Student from './Student';
import StudentInsert from './StudentInsert';

const Students = () => {
    const nextId = useRef(4);    // useRef: Hook
    // console.log(nextId);

    const [students, setStudents] = useState([ // useState: Hook
        { id: 1, name: '홍길동', tel: '010-0000-1111', add: '인천시 미추홀구 문학동' },
        { id: 2, name: '심청이', tel: '010-0000-2222', add: '서울시 송파구 잠실동' },
        { id: 3, name: '강감찬', tel: '010-0000-3333', add: '서울시 구로구 고척동' }
    ]);

    const onInsert = (s) => {
        if(!window.confirm(`${nextId.current}번 학생을 등록하시겠습니까?`)) return;
        const newStudents = students.concat({
            id: nextId.current,
            name: s.name,
            tel: s.tel,
            add: s.add
        });
        setStudents(newStudents);
        nextId.current = nextId.current + 1;
    }

    const onDelete = (id) => {
        if(!window.confirm(`${id}번 학생을 삭제하시겠습니까?`)) return;
        const newStudents = students.filter(s => s.id !== id);  // s.id와 id가 같지 않은 것만 newStudents에
        setStudents(newStudents);
    }

    return (
        <div>
            <StudentInsert onInsert={onInsert}/>
            <h1>학생목록</h1>
            {students.map(s => <Student key={s.id} s={s} onDelete={onDelete}/>)}
        </div>
    )
}

export default Students