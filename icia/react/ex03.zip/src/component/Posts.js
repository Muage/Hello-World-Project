import React, { useEffect, useState } from 'react'

const Posts = ({ id, name }) => {
    const [posts, setPosts] = useState();

    const callAPI = () => {
        fetch('https://jsonplaceholder.typicode.com/posts')
            .then(response => response.json())
            .then(json => {
                const newPosts = json.filter(post => id === post.userId);
                setPosts(newPosts);
                console.log(posts.length);
            });
    }

    useEffect(() => {
        callAPI();
    }, [id]);

    if(!posts) return(<h1>데이터를 불러오는 중입니다...</h1>)

    return (
        <div>
            <h1>{name}'s Post List</h1>
            {posts.map(p => <h5 key={p.id}>{p.id}. {p.title}</h5>)}
        </div>
    )
}

export default Posts