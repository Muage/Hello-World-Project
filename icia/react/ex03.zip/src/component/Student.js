import React from 'react'

const Student = ({s, onDelete}) => {
    const {id, name, tel, add} = s;   // 비구조 할당

    return (
        <div>
            <span>학번: {id}</span>
            <span>이름: {name}</span>
            <span>전화: {tel}</span>
            <span>주소: {add}</span>
            <button onClick={() => onDelete(id)}>삭제</button>
        </div>
    )
}

export default Student