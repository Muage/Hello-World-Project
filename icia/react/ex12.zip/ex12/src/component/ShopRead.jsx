// import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
// import { CKFinder } from '@ckeditor/ckeditor5-ckfinder';
// import { CKEditor } from '@ckeditor/ckeditor5-react';
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Card, Form, Row } from 'react-bootstrap'

const ShopRead = ({ match }) => {
    const code = match.params.code;

    const [shop, setShop] = useState({
        code: code,
        title: "",
        price: 0,
        image:"",
        file: null,
        content: ""
    });
    const {title, price, content, image} = shop;

    const callShop = async() => {
        const result = await axios.get(`/api/shop/read/${code}`);
        setShop(result.data);
    }

    const onChange = (e) => {
        setShop({
            ...shop,
            [e.target.name]: e.target.value
        })
    }

    const onChangeFile = (e) => {
        setShop({
            ...shop,
            file: e.target.files[0],
            image: URL.createObjectURL(e.target.files[0])
        })
    }

    const onChangeContent = (e) => {
        setShop({
            ...shop,
            content: e
        })
        console.log(content);
    }

    const onSubmit = () => {
        
    }

    useEffect(() => {
        callShop();
    }, [])

    if(!shop) return <h1>Loading...</h1>

    return (
        <Row className="d-flex justify-content-center">
            <Card style={{width: "40rem", margin: 10, padding: 20}}>
                <Form>
                    <Form.Control
                        value={title}
                        name="title"
                        className="my-3"
                        placeholder="상품명"
                        onChange={onChange}/>
                    <Form.Control
                        value={price}
                        name="price"
                        type="number"
                        step={1000}
                        className="my-3"
                        placeholder="가격"
                        onChange={onChange}/>
                    <img src={image} width={200}/>
                    <Form.Control
                        className="my-3"
                        type="file"
                        onChange={onChangeFile}/>
                    <hr/>
                    {/* <CKEditor
                        editor={ClassicEditor}
                        data={content}
                        onBlur={(e, editor) => onChangeContent(editor.getData())}
                        config={
                            { ckfinder: {uploadUrl: '/ckUpload?code=' + code} }
                        }/>
                        <hr/> */}
                    <Button
                        style={{width: "100%"}}
                        onClick={onSubmit}>상품정보 수정</Button>
                </Form>
            </Card>
        </Row>
    )
}

export default ShopRead