import './Chat.css';
import React, { Fragment, useContext, useEffect, useRef, useState } from 'react'
import { Card, Row } from 'react-bootstrap';
import { getDatabase, onValue, push, ref, remove, set } from "firebase/database";
import { app } from '../firebase';
import moment from 'moment';
import { UserContext } from '../context/UserContext';

const ChatPage = () => {
    const db = getDatabase(app)

    const wrapRef = useRef(null)

    const {loginUser} = useContext(UserContext)

    const [msg, setMsg] = useState("")
    const [messages, setMessages] = useState([]);

    const sendMessage = async(e) => {
        if(e.ctrlKey && e.keyCode === 13) {
            e.preventDefault();
            // console.log("ctrl")
            return;
        }

        if(e.keyCode === 13) {
            e.preventDefault();

            if(msg === "") {
                alert("보낼 내용을 입력해주세요.");
                return;
            }

            const key = push(ref(db, 'chats/')).key;
            const date = moment(new Date()).format("YYYY-MM-DD HH:mm:ss");
            const uid = loginUser.uid;
            const photo = loginUser.photo;
            // alert(`${key}\n${date}\n${uid}\n${photo}`);

            await set(ref(db, `chats/${key}/`), {
                key: key,
                date: date,
                uid: uid,
                photo: photo,
                text: msg
            });
            setMsg("");
            wrapRef.current.scrollTo(0, wrapRef.current.scrollHeight);
        }
    }

    const getMessage = () => {
        onValue(ref(db, 'chats/'), (snapshot) => {
            let rows = [];

            // console.log("snapshot", snapshot.val())
            snapshot.forEach(row => {
                rows.push(row.val());
            })
            setMessages(rows);
            wrapRef.current.scrollTo(0, wrapRef.current.scrollHeight);
        });
    }

    const onClickDelete = async(e, key) => {
        e.preventDefault();

        if(!window.confirm("해당 메시지를 삭제하시겠습니까?")) return;
        await remove(ref(db, 'chats/' + key));
    }

    useEffect(() => {
        getMessage();
    }, [])

    if(!messages) return <h1>Loading...</h1>

    return (
        <Row className="d-flex justify-content-center">
            <Card style={{width: "60%", margin: 10, padding: 5}}>
                <Card.Title className="my-2">채팅방</Card.Title>
                <div className="wrap" ref={wrapRef}>
                    {messages.map(message =>
                    <Fragment key={message.key}>
                        <div
                            className={message.uid === loginUser.uid ?
                                'chat ch2' :
                                'chat ch1'}>
                            <div><img className="icon" src={message.photo}/></div>
                            <div className="textbox">
                                {message.text}
                                {message.uid === loginUser.uid &&
                                    <a
                                        href="#"
                                        onClick={(e) => onClickDelete(e, message.key)}>
                                        X
                                    </a>
                                }
                            </div>
                            <div style={{fontSize: "12px", color: "gray"}}>
                                {message.date}
                            </div>
                        </div>
                    </Fragment>
                    )}
                </div>
                <div>
                    <textarea
                        onKeyDown={sendMessage}
                        value={msg}
                        onChange={(e) => setMsg(e.target.value)}
                        placeholder='Enter for ....' />
                </div>
            </Card>
        </Row>
    )
}

export default ChatPage