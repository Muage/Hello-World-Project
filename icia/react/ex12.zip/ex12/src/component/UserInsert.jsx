import axios from 'axios';
import React, { useState } from 'react'
import { Button, Card, Form, Row } from 'react-bootstrap'

const UserInsert = ({ history }) => {
    const [form, setForm] = useState({
        uid: "",
        upass: "",
        uname: "",
        file: null
    })
    const {uid, upass, uname, file} = form;

    const onSubmit = async(e) => {
        e.preventDefault();

        if(uid === "" || upass === "" || uname === "") {
            alert("필수 입력란을 확인해주세요.");
            return;
        }

        const formData = new FormData();
        formData.append("uid", uid);
        formData.append("upass", upass);
        formData.append("uname", uname);
        formData.append("file", file);

        if(!window.confirm("새로운 회원을 등록하시겠습니까?")) return;
        await axios.post('/api/user/insert', formData);
        alert("회원가입이 완료되었습니다.");
        history.push('/login');
    }

    const onChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        })
    }

    const onChangeFile = (e) => {
        setForm({
            ...form,
            file: e.target.files[0]
        })
    }

    return (
        <div>
            <Row className="d-flex justify-content-center my-5">
                <Card className="p-3" style={{width: "40%"}}>
                    <Form onSubmit={onSubmit}>
                        <Form.Control
                            name="uid"
                            value={uid}
                            className="my-3"
                            placeholder="아이디"
                            onChange={onChange}/>
                        <Form.Control
                            name="upass"
                            value={upass}
                            type="password"
                            className="my-3"
                            placeholder="비밀번호"
                            onChange={onChange}/>
                        <Form.Control
                            name="uname"
                            value={uname}
                            className="my-3"
                            placeholder="이름"
                            onChange={onChange}/>
                        <Form.Control
                            type="file"
                            className="my-3"
                            onChange={onChangeFile}/>
                        <Button
                            type="submit"
                            style={{width: "100%"}}>회원가입</Button>
                    </Form>
                </Card>
            </Row>
        </div>
    )
}

export default UserInsert