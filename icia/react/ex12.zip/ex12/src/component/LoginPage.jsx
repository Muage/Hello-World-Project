import axios from 'axios'
import React, { useContext, useState } from 'react'
import { Button, Card, Form, Row } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { UserContext } from '../context/UserContext'

const LoginPage = ({ history }) => {
    const {loginUser, setLoginUser} = useContext(UserContext)
    
    const [form, setForm] = useState({
        uid: "",
        upass: ""
    })

    const onChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        })
    }

    const onSubmit = async(e) => {
        e.preventDefault();

        if(form.uid === "" || form.upass === "") {
            alert("아이디와 비밀번호를 입력해주세요");
            return;
        }
        const result = await axios.post('/api/user/login', form);
        if(result.data === 0) {
            alert("아이디가 존재하지 않습니다.");
        } else if( result.data === 2) {
            alert("비밀번호를 확인해주세요.");
        } else {
            // alert("로그인 성공");
            sessionStorage.setItem("uid", form.uid);
            const getLoginUser = async() => {
                const result = await axios.get(`/api/user/read/${sessionStorage.getItem("uid")}`);
                setLoginUser(result.data);
            }
            history.push('/');
        }
    }

    return (
        <div>
            <Row className="d-flex justify-content-center my-5">
                <Card className="p-3" style={{width: "40%"}}>
                    <Form onSubmit={onSubmit}>
                        <Form.Control
                            name="uid"
                            value={form.uid}
                            className="my-3"
                            placeholder="아이디"
                            onChange={onChange}/>
                        <Form.Control
                            type="password"
                            name="upass"
                            value={form.upass}
                            placeholder="비밀번호"
                            onChange={onChange}/>
                        <Button
                            type="submit"
                            className="my-3"
                            style={{width: "100%"}}>로그인</Button>
                        <Link to='/user/insert'>회원가입</Link>
                    </Form>
                </Card>
            </Row>
        </div>
    )
}

export default LoginPage