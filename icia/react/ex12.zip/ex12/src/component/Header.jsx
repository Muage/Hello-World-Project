import axios from 'axios'
import React, { useContext, useEffect } from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap'
import { withRouter } from 'react-router-dom'
import { UserContext } from '../context/UserContext'

const Header = ({ history }) => {
    const {loginUser, setLoginUser} = useContext(UserContext);

    const onClick = (e) => {
        e.preventDefault();

        const href = e.target.getAttribute("href");
        history.push(href);
    }

    const onClickLogout = (e) => {
        e.preventDefault();
        sessionStorage.clear();
        history.push('/');
    }

    const getLoginUser = async() => {
        const result = await axios.get(`/api/user/read/${sessionStorage.getItem("uid")}`);
        setLoginUser(result.data);
    }

    useEffect(() => {
        if(sessionStorage.getItem("uid")) {
            getLoginUser();
        }
    })

    return (
        <>
          <Navbar bg="primary" variant="dark">
            <Container>
                <Navbar.Brand href='/' onClick={onClick}>Home</Navbar.Brand>
                <Nav className="me-auto">
                    <Nav.Link href='/movie' onClick={onClick}>영화예약</Nav.Link>
                    <Nav.Link href='/chat' onClick={onClick}>채팅</Nav.Link>
                    <Nav.Link href='/shop' onClick={onClick}>상품관리</Nav.Link>
                </Nav>
                <Nav>
                    {sessionStorage.getItem("uid") ?
                        <>
                        <Nav.Link
                            href={`/user/read/${loginUser.uid}`}
                            onClick={onClick}>{loginUser.uname} 님</Nav.Link>
                            채팅
                        <Nav.Link
                            href='#'
                            onClick={onClickLogout}>로그아웃</Nav.Link>
                        </>:
                        <Nav.Link
                            href='/login'
                            onClick={onClick}>로그인</Nav.Link>
                    }
                </Nav>
            </Container>
          </Navbar>
        </>
    )
}

export default withRouter(Header)