import React, { useContext } from 'react'
import { Button, Card, Form, Row } from 'react-bootstrap'
import { UserContext } from '../context/UserContext'

const UserRead = () => {
    const {loginUser} = useContext(UserContext);

    return (
        <div>
            <Row className="d-flex justify-content-center my-5">
                <Card className="p-3" style={{width: "50%"}}>
                    <Card.Img
                        src={loginUser.photo}
                        style={{width: "30%", margin: "0 auto"}}/>
                    <Card.Title>
                        {loginUser.uid}({loginUser.uname})
                    </Card.Title>
                    <Button className="my-3" variant="outline-primary">수정하기</Button>
                </Card>
            </Row>
        </div>
    )
}

export default UserRead