import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Button, Card, Row } from 'react-bootstrap'

const MoviePage = () => {
    const [movies, setMovies] = useState([])

    const callMovies = async() => {
        const result = await axios.get('/api/crawl/cgv');
        setMovies(result.data);
    }

    const onClick = (link) => {
        window.open(link, "_blank")
    }

    useEffect(() => {
        callMovies();
    }, [])

    if(!movies) return <h1>Loading...</h1>

    return (
        <div>
            <Row className="d-flex justify-content-center">
                {movies.map(movie =>
                    <Card key={movie.no} style={{width: "18rem", margin: 10}}>
                        <Card.Img src={movie.image}/>
                        <Card.Body>
                            <Card.Title className="ellipsis">
                                {movie.no} {movie.title}
                            </Card.Title>
                            <Button variant="primary"
                                onClick={() => onClick(movie.link)}>예약하기
                            </Button>
                        </Card.Body>
                    </Card>
                )}
            </Row>
        </div>
    )
}

export default MoviePage