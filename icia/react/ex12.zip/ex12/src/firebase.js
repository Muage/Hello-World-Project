import { initializeApp } from "firebase/app";

const firebaseConfig = {
    apiKey: "AIzaSyDbblL3NE_YBcNiEFtP1cz5yvGAfSIHU40",
    authDomain: "ex10-aa838.firebaseapp.com",
    databaseURL: "https://ex10-aa838-default-rtdb.firebaseio.com",
    projectId: "ex10-aa838",
    storageBucket: "ex10-aa838.appspot.com",
    messagingSenderId: "336492579078",
    appId: "1:336492579078:web:a26335418bf0345bfcf687",
    measurementId: "G-8ZGS6N1YN1"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);