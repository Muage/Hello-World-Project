import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, Switch } from 'react-router-dom';
import HomePage from './component/HomePage';
import MoviePage from './component/MoviePage';
import Header from './component/Header';
import LoginPage from './component/LoginPage';
import UserInsert from './component/UserInsert';
import { useState } from 'react';
import { UserContext } from './context/UserContext';
import UserRead from './component/UserRead';
import ChatPage from './component/ChatPage';
import ShopPage from './component/ShopPage';

function App() {
	const [loginUser, setLoginUser] = useState("");

	return (
		<UserContext.Provider value={{loginUser, setLoginUser}}>
			<div className="App">
				<Header/>

				<Switch>
					<Route path='/' component={HomePage} exact/>
					<Route path='/movie' component={MoviePage}/>
					<Route path='/login' component={LoginPage}/>
					<Route path='/user/insert' component={UserInsert}/>
					<Route path='/user/read/:uid' component={UserRead}/>
					<Route path='/chat' component={ChatPage}/>
					<Route path='/shop' component={ShopPage}/>
				</Switch>
			</div>
		</UserContext.Provider>
	);
}

export default App;
