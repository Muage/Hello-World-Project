import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const BoardRead = ({ match, history }) => {
    const no = match.params.bno;

    const [form, setForm] = useState({
        bno: '',
        title: '',
        content: '',
        writer: '',
        regdata: ''
    });
    const {bno, title, content, writer, regdate} = form;

    const callAPI = async() => {
        const result = await axios.get(`/board/read/${no}`);
        setForm(result.data);
    }

    const onClickDelete = async() => {
        if(!window.confirm(`${no}번 게시글을 삭제하시겠습니까?`)) return;

        await axios.post(`/board/delete/${no}`);
        history.push('/board/list');
    }
    
    useEffect(() => {
        callAPI();
    }, []);

    return (
        <div>
            <h4>[{bno}] {title}</h4>
            <h6>{regdate} ({writer})</h6>
            <hr/>
            <p>{content}</p>
            <Link to={`/board/update/${no}`}>
                <Button variant="outline-secondary" size="sm">
                    수정
                </Button>
            </Link>
            <Button variant="secondary" size="sm"
                onClick={onClickDelete}>삭제</Button>
        </div>
    )
}

export default BoardRead