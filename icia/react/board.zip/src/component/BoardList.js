import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Alert, Button, Form, Stack, Table } from 'react-bootstrap';
import Pagination from 'react-js-pagination';
import BoardItem from './BoardItem';
import './Paging.css';

const BoardList = () => {
    const [boards, setBoards] = useState();
    const [page, setPage] = useState(1);
    const [total, setTotal] = useState(0);
    const [word, setWord] = useState('');

    const callAPI = async() => {
        const result = await axios.get(`/board/list?page=${page}&word=${word}`);
        setBoards(result.data.list);
        setTotal(result.data.total);
    }

    const onKeyDown = (e) => {
        if(e.keyCode === 13) {
            setPage(1);
            callAPI();
        }
    }

    useEffect(() => {
        callAPI();
    }, [page]);

    if(!boards) return <h2>데이터를 불러오는 중입니다...</h2>

    return (
        <div>
            <Stack direction="horizontal" gap={3}>
                <Form.Control
                    className="me-auto"
                    placeholder='검색어'
                    value={word}
                    onChange={(e) => setWord(e.target.value)}
                    onKeyDown={onKeyDown}/>
                <Button variant="success">Search</Button>
            </Stack>
            <Alert variant="success">전체 {total}</Alert>
            <Table striped>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Title</th>
                        <th>Writer</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    {boards.map(board =>
                        <BoardItem key={board.bno} board={board}/>
                    )}
                </tbody>
            </Table>
            
            <Pagination
                activePage={page}
                itemsCountPerPage={10}
                totalItemsCount={total}
                pageRangeDisplayed={5}
                prevPageText={"‹"}
                nextPageText={"›"}
                onChange={(e) => setPage(e)}/>
        </div>
    )
}

export default BoardList