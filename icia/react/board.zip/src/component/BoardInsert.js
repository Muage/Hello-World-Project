import axios from 'axios';
import React, { useRef, useState } from 'react'
import { Button } from 'react-bootstrap';

const BoardInsert = ({ history }) => {
    const refTitle = useRef();
    
    const [form, setForm] = useState({
        title: '',
        writer: 'blue',
        content: ''
    });
    const {title, writer, content} = form;

    const onChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        })
    }

    const onSubmit = async() => {
        if(title === "") {
            alert("제목을 입력해주세요.");
            refTitle.current.focus();
            return;
        }
        if(!window.confirm(`${JSON.stringify(form, null, 4)}를 등록하시겠습니까?`)) return;

        // 등록
        await axios.post('/board/insert', form);
        history.push('/board/list')
    }

    return (
        <div>
            <input placeholder="Title"
                name="title"
                value={title}
                size={50}
                ref={refTitle}
                onChange={onChange}/>
            <hr/>
            <input placeholder="Writer"
                name="writer"
                value={writer}
                size={50}
                onChange={onChange} readOnly/>
            <hr/>
            <textarea placeholder="Content"
                name="content"
                value={content}
                rows={10} cols={80}
                onChange={onChange}/>
            <hr/>
            <Button
                className='reset'
                variant="outline-secondary"
                size="sm">Reset</Button>
            <Button
                className='submit'
                variant="secondary"
                size="sm"
                onClick={onSubmit}>Register</Button>
        </div>
    )
}

export default BoardInsert