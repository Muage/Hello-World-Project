import { Link, Route } from 'react-router-dom';
import './App.css';
import BoardPage from './component/BoardPage';
import HomePage from './component/HomePage';
import 'bootstrap/dist/css/bootstrap.css';

function App() {
	return (
		<div className="App">
			<div className='main_menu'>
				<Link to='/'>Home</Link>
				<Link to='/board'>Board</Link>
			</div>
			<hr/>
			<Route path='/' component={HomePage} exact/>
			<Route path='/board' component={BoardPage}/>
		</div>
	);
}

export default App;
