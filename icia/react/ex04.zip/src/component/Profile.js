import React from 'react'
import { useParams } from 'react-router-dom';

const data = {
    shim: {
        name: '심청이',
        description: '리액트를 좋아하는 개발자'
    },
    hong: {
        name: '홍길동',
        description: '고전 소설 홍길동전의 주인공'
    },
    lee: {
        name: '이순신',
        description: '조선시대 장군'
    }
};

const Profile = () => {
    const {userid} = useParams();
    const profile = data[userid];

    if(!profile) return(<h1>아이디를 찾을 수 없습니다.</h1>)

    
    return (
        <div>
            <h3>이름: {profile.name}</h3>
            <h3>소개: {profile.description}</h3>
        </div>
    )
}

export default Profile