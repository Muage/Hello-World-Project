import React, { useRef, useState } from 'react'
import TodoInsert from './TodoInsert';
import TodoItem from './TodoItem';

const TodoList = () => {
    const nextId = useRef(4);

    const [todos, setTodos] = useState([
        { id: 1, text: '리액트의 기초 알아보기', checked: true },
        { id: 2, text: '컴포넌트 스타일링해 보기', checked: true },
        { id: 3, text: '일정 관리 앱 만들어 보기', checked: false }
    ]);
    
    const onInsert = (text) => {
        const todo = {
            id: nextId.current,
            text: text,
            checked: false
        }
        setTodos(todos.concat(todo));
        nextId.current = nextId.current + 1;
    };

    const onDelete = (id) => {
        setTodos(todos.filter(todo => id !== todo.id));
    };

    const onToggle = (id) => {
        const newTodos = todos.map(todo =>
            id === todo.id ?
            {...todo, checked: !todo.checked} :
            todo
        );
        setTodos(newTodos);
    };

    // useEffect(() => {
    //     console.log('onInsert... 생성')
    // }, [onInsert]);

    return (
        <div>
            <h1>Todo Insert</h1>
            <TodoInsert nextId={nextId.current} onInsert={onInsert}/>

            <h1>Todo List</h1>
            {todos.map(todo =>
                <TodoItem key={todo.id} todo={todo} onDelete={onDelete} onToggle={onToggle}/>
            )}
        </div>
    )
}

export default TodoList