import React from 'react'
import { useLocation } from 'react-router-dom'
import qs from 'qs';

const About = () => {    
    const query = qs.parse(useLocation().search, {ignoreQueryPrefix:true});

    const {detail, id} = query;

    console.log(`detail=${detail}, id=${id}`);

    return (
        <div>
            <h1>웹사이트 소개 페이지 입니다.</h1>
        </div>
    )
}

export default About