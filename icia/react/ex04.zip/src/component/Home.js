import React from 'react'

const Home = () => {
  return (
    <div>
        <h1>가장 먼저 보이는 페이지 입니다.</h1>
    </div>
  )
}

export default Home