// import React, { useCallback, useEffect, useMemo, useState } from 'react'
import React, { useEffect, useState } from 'react'

const MemoCallback = () => {
    const [number, setNumber] = useState(3);
    const [isKorea, setIsKorea] = useState(true);

    // const location = useMemo(() => {    // useMemo: Hook, 값을 저장하고 [값]이 바뀔 때마다 값을 가져옴
    //     console.log('location 변경: ', isKorea);
    //     return isKorea ? '한국' : '외국';
    // }, [isKorea]);

    // const onChange = useCallback((e) => {   // useCallback: Hook, 함수를 저장하고 [값]이 바뀔 때마다 함수를 가져옴
    //     console.log('number 변경: ', number);
    //     setNumber(e.target.value);
    // }, [number]);

    // const onChange = (e) => {
    //     console.log('number 변경', number);
    //     return setNumber(e.target.value);   // return은 생략 가능
    // }

    // useEffect(() => {
    //     console.log('location 변경', location);
    // });
    
    const location = () => {
        console.log('location: ', isKorea);
        return isKorea ? '한국' : '외국';
    }

    const onChange = (e) => {
        console.log('number: ', number);
        return setNumber(e.target.value);
    }

    useEffect(() => {
        console.log('렌더링: ', isKorea, number);
    })

    return (
        <div>
            <h2>하루에 몇 끼 먹어요?</h2>
            <input type="number" step={1} value={number} onChange={onChange}/>
            <h2>어느 나라에 있나요?</h2>
            <p>나라이름: {location()}</p>
            <button onClick={() => setIsKorea(!isKorea)}>비행기를 타자</button>
        </div>
    )
}

export default MemoCallback