import React from 'react'
import { Link, Route, Routes } from 'react-router-dom'
import Profile from './Profile'

const Profiles = () => {
    return (
        <div>
            <Link to="/profiles/hong">홍길동</Link>&nbsp;&nbsp;&nbsp;&nbsp;
            <Link to="/profiles/shim">심청이</Link>&nbsp;&nbsp;&nbsp;&nbsp;
            <Link to="/profiles/lee">이순신</Link>
            <Routes>
                <Route path=":userid" element={<Profile/>}/>
            </Routes>
        </div>
    )
}

export default Profiles