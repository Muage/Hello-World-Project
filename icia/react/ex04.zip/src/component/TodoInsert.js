import React, { useCallback, useState } from 'react'

const TodoInsert = ({nextId, onInsert}) => {
    const [text, setText] = useState('');

    // 렌더링 될 때마다 실행됨
    // const onChange = (e) => {
    //     console.log('렌더링...' + text);
    //     setText(e.target.value);
    // }

    // 값이 변경되면 함수 실행
    const onChange = useCallback((e) => {
        setText(e.target.value);
    }, []);

    const onSubmit = (e) => {
        e.preventDefault();
        if(!window.confirm(`${nextId}번 할 일을 저장하시겠습니까?`)) return;
        onInsert(text);
        setText('');
        
    }

    return (
        <form onSubmit={onSubmit}>
            <input value={text} placeholder='여기에 할 일을 입력하세요.'
                onChange={onChange}/>
            <button type="submit">등록</button>
        </form>
    )
}

export default TodoInsert