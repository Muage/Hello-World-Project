import React from 'react'

const TodoItem = ({todo ,onDelete, onToggle}) => {
    const {id, text, checked} = todo;

    const styleTable = {
        borderCollapse: 'collapse',
	    margin: '10px auto'
    }

    const styleChecked = {
        width: 10
    }

    const onDeleteItem = () => {
        if(!window.confirm(`${id}번 할 일을 삭제하시겠습니까?`)) return;
        onDelete(id);
    }

    return (
        <table style={styleTable}>
            <tbody>
                <tr className={checked && 'checked'}>
                    <td style={styleChecked}>
                        <input type="checkbox" checked={checked} readOnly
                            onClick={() => onToggle(id)}/>
                    </td>
                    <td style={{width: 300}}>
                        {id}: {text}
                    </td>
                    <td>
                        <button onClick={onDeleteItem}>삭제</button>
                    </td>
                </tr>
            </tbody>
        </table>

        // <div className={checked && 'checked'}>
        //     <span style={styleChecked}>
        //         <input type="checkbox" checked={checked} readOnly
        //              onClick={() => onToggle(id)}/>
        //     </span>
        //     <span style={{width: 300}}>
        //         {id}: {text}
        //     </span>
        //     <button onClick={onDeleteItem}>삭제</button>
        // </div>
    )
}

export default TodoItem