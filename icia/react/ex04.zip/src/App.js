import './App.css';
import RouterExample from './component/RouterExample';
// import MemoCallbackEx from './component/MemoCallback';
// import TodoList from './component/TodoList';

const App = () => {
	return (
		<div className="App">
			{/* <MemoCallbackEx/> */}

			{/* <TodoList/> */}

			<RouterExample/>
		</div>
	);
}

export default App;