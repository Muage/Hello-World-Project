import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link, withRouter } from 'react-router-dom';

const PostRead = ({ match, history }) => {
    const id = match.params.id;
    const loginId = sessionStorage.getItem('loginId');

    const [form, setForm] = useState({
        title: '',
        body: '',
        fdate: '',
        userid: ''
    });

    const {title, body, fdate, userid} = form;

    const callAPI = async() => {
        const result = await axios.get(`/posts/${id}`);
        setForm(result.data);
    }

    useEffect(() => {
        console.log('.....', id);
        callAPI();
    }, [])

    if(title === '') return (<h1>데이터를 불러오는 중입니다.</h1>);

    return (
        <div>
            <div>
                <div>
                    <span>{fdate} ({userid})</span>
                </div>
                <hr/>
                <div>{title}</div>
                <hr/>
                <div>{body}</div>
                <hr/>
                <div className='buttons'>
                {loginId === userid &&
                    <Link to={`/posts/update/${id}`}><button>수정</button></Link>
                }
                    <button onClick={() => history.goBack()}>목록</button>
                </div>
            </div>
        </div>
    )
}

export default withRouter(PostRead)