import React, { useEffect, useState } from 'react'
import { Link, withRouter } from 'react-router-dom';
import qs from 'qs'
import axios from 'axios';
import ErrorPage from './ErrorPage';
import PostItem from './PostItem';

const PostList = ({ location }) => {
    const search = qs.parse(location.search, {ignoreQueryPrefix: true});
    const page = !search.page ? 1 : parseInt(search.page);
    // console.log(page);

    const [error, setError] = useState();
    const [posts, setPosts] = useState([]);
    const [last, setLast] = useState(1);
    const [word, setWord] = useState('');
    const [total, setTotal] = useState(0);
    const [checkItems, setCheckItems] = useState([]);

    const callAPI = async() => {
        try{
            const result = await axios.get(`/posts?page=${page}&word=${word}`);
            setPosts(result.data.list);
            // console.log(result.data);
            setLast(Math.ceil(result.data.total / 10));
            setTotal(result.data.total);
        } catch(e) {
            setError(e.message);
        }
    }

    const onChangeWord = (e) => {
        setWord(e.target.value);
    }

    const onClickOut = () => {
        alert(checkItems);
    }

    useEffect(() => {
        callAPI();
    }, [page, word])

    if(error) return (<ErrorPage error={error}/>);

    if(!posts) return (<h1>데이터를 불러오는 중입니다...</h1>);

    const onSingleCheck = (checked, id) => {
        if(checked) {
            setCheckItems(checkItems.concat(id));   // id 추가
        } else {
            setCheckItems(checkItems.filter(item => id !== item));    // id 삭제
        }
    }

    const onAllCheck = (checked) => {
        if(checked) {
            const all = [];
            posts.forEach(post => all.push(post.id));
            setCheckItems(all); // 전체 선택
        } else {
            setCheckItems([]);  // 전체 해제
        }
    }

    return (
        <div>
            <h1>Post List</h1>
            <div>
                <input type='checkbox'
                    onChange={(e) => onAllCheck(e.target.checked)}
                    checked={checkItems.length === posts.length ? true : false}/>
                <button onClick={onClickOut}>선택출력</button>
                <input value={word} placeholder='검색어'
                    onChange={onChangeWord}/>
                <span>검색수: {total}</span>
            </div>
            {posts.map(post =>
                <div key={post.id} className="posts">
                    <PostItem post={post}
                        checkItems={checkItems}
                        onSingleCheck={onSingleCheck}/>
                </div>
            )}
            <div className='buttons'>
                <Link to={`/posts/list/?page=${page - 1}`}>
                    <button disabled={page === 1 && true}>이전</button>
                </Link>
                <span>{page} / {last}</span>
                <Link to={`/posts/list/?page=${page + 1}`}>
                    <button disabled={page === last && true}>다음</button>
                </Link>
            </div>
        </div>
    )
}

export default withRouter(PostList)