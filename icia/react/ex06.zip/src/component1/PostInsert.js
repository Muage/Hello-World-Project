import axios from 'axios';
import React, { useRef, useState } from 'react'

const PostInsert = ({ history }) => {
    const loginId = sessionStorage.getItem('loginId');

    const [form, setForm] = useState({
        title: '',
        body: '',
        userid: loginId
    });

    const {title, body, userid} = form;

    const refTitle = useRef();

    const onChange = (e) => {
        const newForm = {
            ...form,
            [e.target.name]: e.target.value
        }
        setForm(newForm);
    }

    const onSubmit = async(e) => {
        e.preventDefault();
        if(title === '') {
            alert('제목을 입력해주세요.');
            refTitle.current.focus();
            return;
        }
        // alert(JSON.stringify(form, null, 4));
        await axios.post('/posts/insert', form);
        history.push('/posts/list');
    }

    return (
        <div className='postInsert'>
            <form className='postForm' onSubmit={onSubmit}>
                <input value={title} ref={refTitle} name="title" placeholder='제목을 입력해주세요.'
                    onChange={onChange}/>
                <textarea value={body} name="body" placeholder='내용을 입력해주세요.'
                    onChange={onChange}/>
                <div className='buttons'>
                    <button type="submit">등록</button>
                    <button type="reset">취소</button>
                </div>
            </form>
        </div>
    )
}

export default PostInsert