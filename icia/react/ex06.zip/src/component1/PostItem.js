import React from 'react'
import { Link } from 'react-router-dom';

const PostItem = ({ post, checkItems, onSingleCheck }) => {
    const {id, title, body, userid, fdate} = post;

    return (
        <div className='row'>
            <span className='chk'>
                <input type='checkbox'
                    checked = {checkItems.includes(id) ? true : false}
                    onChange={(e) => {onSingleCheck(e.target.checked, id)}}/>
            </span>
            <span className='pid'>{id}</span>
            <Link to={`/posts/read/${id}`}>
                <span className='title'>{title}</span>
            </Link>
            <span className='userid'>{userid}</span>
            <span className='fdate'>{fdate}</span>
            {/* <span className='body'>{body}</span> */}
        </div>
    )
}

export default PostItem