import React, { useEffect, useState } from 'react'
import { Link, NavLink } from 'react-router-dom';

const Header = () => {
	const [loginId, setLoginId] = useState('');

	const onClickLogout = () => {
		sessionStorage.removeItem('loginId');
		setLoginId('');
	}

	useEffect(() => {
		// console.log('.....', loginId);
		setLoginId(sessionStorage.getItem('loginId'));
		// alert(loginId);
	})

    return (
        <div>
            <NavLink to="/posts" activeClassName='active'>게시글</NavLink>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<NavLink to="/users" activeClassName='active'>사용자</NavLink>
			<span style={{float: 'right'}}>
				{loginId ?
					<span>{loginId}님, 반갑습니다
						<button onClick={onClickLogout}>로그아웃</button></span> :
					<Link to="/login"><button>로그인</button></Link>
				}
			</span>
			<hr/>
        </div>
    )
}

export default Header