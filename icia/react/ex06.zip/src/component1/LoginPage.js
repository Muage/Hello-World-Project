import axios from 'axios';
import React, { useState } from 'react'
import Header from './Header';
import qs from 'qs'

const LoginPage = ({ history, location }) => {
    const style = {
        width: 300,
        margin: '0 auto',
        textAlign: 'center'
    }

    const search = qs.parse(location.search, {ignoreQueryPrefix: true});
    const target = search.target;

    const [user, setUser] = useState({
        uid: '',
        upass: ''
    })
    const {uid, upass} = user;

    const [message, setMessage] = useState('');

    const onChangeUser = (e) => {
        const newUser = {
            ...user,
            [e.target.name]: e.target.value
        }
        setUser(newUser);
        // console.log('upass', upass);
    }

    const onSubmit = async(e) => {
        e.preventDefault();

        const data = {uid: uid, upass: upass};
        const result = await axios.post('/users/login', data);

        if(!result.data.uid) {
            setMessage('아이디가 존재하지 않습니다.');
        } else if(result.data.upass !== upass) {
            setMessage('비밀번호가 일치하지 않습니다.')
        } else {
            alert('로그인 성공');
            sessionStorage.setItem('loginId', uid);
            if(target) {
                history.push(target);
            } else {
                history.push("/");
            }
        }
        // alert(JSON.stringify(result.data, null, 4));
        // alert(`${uid}, ${upass}`);
    }

    return (
        <div>
            <Header/>
            <h1>로그인</h1>
            <form style={style} onSubmit={onSubmit}>
                <div>
                    <input name="uid"
                        value={uid} placeholder='아이디'
                        onChange={onChangeUser}/>
                </div>
                <div>
                    <input name="upass" type="password"
                        value={upass} placeholder='비밀번호'
                        onChange={onChangeUser}/>
                </div>
                <div>
                    <button>로그인</button>
                </div>
            </form>
            <div style={{color: 'red'}}>
                <h5>
                    {message && message}
                </h5>
            </div>
        </div>
    )
}

export default LoginPage