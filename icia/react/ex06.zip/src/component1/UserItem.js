import React from 'react'
import { Link } from 'react-router-dom'

const UserItem = ({ user, onSingleCheck, items }) => {
    const {uid, uname, status} = user;

    return (
        <div>
            <h3>
                <input type="checkbox"
                    onChange={(e) => onSingleCheck(e.target.checked, uid)}
                    checked = {items.includes(uid)}/>&nbsp;    {/* 비구조 할당하지 않으면 user.uid */}
                <Link to={`/users/read/${uid}`}>
                    {uid} ({uname})
                </Link>
                <span style={{color: status}}>등급: {status}</span>
            </h3>
        </div>
    )
}

export default UserItem