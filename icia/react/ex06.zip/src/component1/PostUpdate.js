import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react'
import { withRouter } from 'react-router-dom';

const PostUpdate = ({ match, history }) => {
    const id = match.params.id;

    const [form, setForm] = useState({
        id: id,
        title: '',
        body: ''
    });
    // const [blocking, setBlocking] = useState(false);

    const {title, body, userid} = form;

    const refTitle = useRef();

    const onChange = (e) => {
        const newForm = {
            ...form,
            [e.target.name]: e.target.value
        }
        setForm(newForm);
    }

    const onSubmit = async(e) => {
        e.preventDefault();
        if(title === '') {
            alert('제목을 입력해주세요.');
            refTitle.current.focus();
            return;
        }
        // alert(JSON.stringify(form, null, 4));
        if(!window.confirm(`${id}번 게시글을 수정하시겠습니까?`)) return;
        await axios.post('/posts/update', form);
        alert('수정되었습니다.');
        history.go(-2);
    }

    const onClickDelete = async() => {
        if(!window.confirm(`${id}번 게시글을 삭제하시겠습니까?`)) return;
        await axios.post(`/posts/delete/${id}`);
        alert(`${id}번 게시글이 삭제되었습니다.`);
        history.go(-2);
    }

    const callAPI = async() => {
        const result = await axios.get(`/posts/${id}`);
        setForm(result.data);
    }

    useEffect(() => {
        callAPI();
        // setBlocking(true);
        // const block = history.block('정말 뒤로 가시겠습니까?');
        // return () => {
        //     block();
        // }
    }, [])

    useEffect(() => {
        const message = history.block('페이지를 떠나시겠습니까?');
        return () => {
            if(message) message();
        }
    }, [history]);

    if(title === '') return(<h1>데이터를 불러오는 중입니다.</h1>);

    return (
        <div className='postInsert'>
            <form className='postForm' onSubmit={onSubmit}>
                <input value={title} ref={refTitle} name="title" placeholder='제목을 입력해주세요.'
                    onChange={onChange}/>
                <textarea value={body} name="body" placeholder='내용을 입력해주세요.'
                    onChange={onChange}/>
                <div className='buttons'>
                    <button type="submit">수정</button>
                    <button type="button" onClick={onClickDelete}>삭제</button>
                    <button type="reset">취소</button>
                </div>
            </form>
        </div>
    )
}

export default withRouter(PostUpdate)