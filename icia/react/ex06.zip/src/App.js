import { Route } from 'react-router-dom';
import './App.css';
import Home from './component1/Home';
import LoginPage from './component1/LoginPage';
import PostsPage from './component1/PostsPage';
import UsersPage from './component1/UsersPage';

function App() {
	return (
		<div className="App">
			{/* MenuComponent 만들어 주면 좋음 */}
			<Route path="/" component={Home} exact/>
			<Route path="/posts" component={PostsPage}/>
			<Route path="/users" component={UsersPage}/>
			<Route path="/login" component={LoginPage}/>
		</div>
	);
}

export default App;