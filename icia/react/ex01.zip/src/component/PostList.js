import axios from 'axios';
import React, { useEffect, useState } from 'react'

const PostList = () => {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(1);
    const [last, setLast] = useState(1);

    const callAPI = async() => {
        setLoading(true);
        const result = await axios.get('/posts/list.json?page=' + page);
        setPosts(result.data.list);
        const total = result.data.total;
        setLast(Math.ceil(total / 10));
        setLoading(false);
    }

    useEffect(() => {
        callAPI();
    }, [page])

    const onClick = () => {
        setPage(page + 1);
    }

    if(loading) return (<h1>로딩중입니다...</h1>);

    return (
        <div>
            {/* <textarea rows={30} cols={130} value={JSON.stringify(posts, null, 4)}/>
            <button onClick={callAPI}>데이터불러오기</button> */}
            {posts.map(post =>
                <div key={post.id}>
                    <h5>{post.title}({post.userid})</h5>
                </div>
            )}
            <button onClick={() => setPage(page - 1)}
                disabled={page === 1 && true}>이전</button>
            <span> {page} / {last} </span>
            <button onClick={() => setPage(page + 1)}
                disabled={page === last && true}>다음</button>
        </div>
    )
}

export default PostList