import React, { useState } from 'react'

const Address = () => {
    let tel = '010-0000-1111';  // 일반변수, 값이 바뀌어도 render 되지 않음
    const changeTel = () => {
        tel = '010-0000-2222';
        alert(tel);
    }

    const [form, setForm] = useState({
        name: '홍길동',
        age: '20',
        job: '대학생',
        address: '인천시 미추홀구 문학동'
    });
    const {name, age, job, address} = form;
    const onChangeForm = (e) => {
        const nextForm = {
            ...form,    // 원래 form 값 복제
            [e.target.name]: e.target.value // 새로 변경된 값 입력
        }
        setForm(nextForm);
    }
    const onClickConfirm = () => {
        setForm({
            name: '',
            age: 0,
            job: '',
            address: ''
        });
    }

    return (
        <div>
            <h1>주소등록</h1>
            <div className='address'>
                <input type="text" name="name" value={name} placeholder="이름"
                    onChange={onChangeForm}/>
                <input type="text" name="age" value={age} placeholder="나이"
                    onChange={onChangeForm}/>
                <input type="text" name="job" value={job} placeholder="직업"
                    onChange={onChangeForm}/>
                <input type="text" name="address" value={address} placeholder="주소"
                    onChange={onChangeForm}/>
                <input type="text" name="tel" value={tel} placeholder="전화번호"
                    onClick={changeTel}/>
                <button onClick={onClickConfirm}>확인</button>
            </div>
            <div>
                <h2>입력결과</h2>
                <h5>이름은 {name} 입니다.</h5>
                <h5>나이는 {age}살 입니다.</h5>
                <h5>직업은 {job} 입니다.</h5>
                <h5>주소는 {address} 입니다.</h5>
                <h5>전화번호는 {tel} 입니다.</h5>
            </div>
        </div>
    )
}

export default Address