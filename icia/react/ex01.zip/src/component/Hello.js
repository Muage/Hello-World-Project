import React from 'react'
import World from './World'

// 함수형 컴포넌트
const Hello = () => {
	return (
    	<div>
        	<h1>Hello</h1>
        	<World/>
    	</div>
  	)
}

export default Hello