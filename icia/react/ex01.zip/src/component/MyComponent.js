import React, { Children } from 'react'

const MyComponent = (props) => {
    const {name, age} = props;
    return (
        <div>
            <h1>이름: {name}</h1>
            <h1>나이: {age}</h1>

            {props.children}
        </div>
    )
}

export default MyComponent