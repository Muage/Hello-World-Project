import React from 'react'

const StyleExample = () => {
    const name = null;
    const style = {
        backgroundColor: 'yellow',
        color: 'red'
    }
    
    return (
        <div>
            <h1 style = { style }>{name === '리액트' ? '리액트' : name} 안녕!</h1>   {/* name이 '리액트'와 같으면 '리액트'를, 같지 않으면 name을 출력 */}
            <h1>{name === '리액트' && '리액트'} 안녕!</h1> {/* name이 '리액트'와 같으면 출력 O, 같지 않으면 출력 X */}
            <h1 style = {{color: 'green', backgroundColor: 'orange'}}>
                {name || '리액트'} 안녕!    {/* name이 null이면 '리액트'를, 같지 않으면 name을 출력 */}
            </h1>
            <h2>잘 작동하나요?</h2>
        </div>
    )
}

export default StyleExample