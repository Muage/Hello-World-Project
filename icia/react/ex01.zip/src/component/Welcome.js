import React, { Component } from 'react'

// 클래스형 컴포넌트
export class Welcome extends Component {
  render() {
    return (
      <div>
        <h3>Welcome</h3>
      </div>
    )
  }
}

export default Welcome