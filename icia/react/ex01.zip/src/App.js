import './App.css';
// import Address from './component/Address';
// import ChangeExample from './component/ChangeExample';
// import Counter from './component/Counter';
// import Hello from './component/Hello';
// import ListSample from './component/ListSample';
// import MyComponent from './component/MyComponent';
import PostList from './component/PostList';
// import Posts from './component/Posts';
// import Product from './component/Product';
// import Say from './component/Say';
// import StyleExample from './component/StyleExample';
// import Todos from './component/Todos';
// import Toggle from './component/Toggle';
// import Welcome from './component/Welcome';

// function App() {
const App = () => {
    return (
        // <div className = "App"
        //     // 이렇게도 주석이 가능합니다.
        // >
        //     {/* jsx의 주석입니다. */}
        //     <StyleExample/> {/* 컴포넌트 */}
        //     <hr/>
        //     <StyleExample/>
            
        //     <hr/>
        //     <Hello/>
        //     <Hello/>
        //     <Welcome/>

        //     <hr/>
        //     <MyComponent name="홍길동" age={26}/>

        //     <hr/>
        //     <MyComponent>
        //         <h1>이름은 홍길동입니다.</h1>
        //         <h1>나이는 26살입니다.</h1>
        //     </MyComponent>

        //     <hr/>
        //     <Counter/>

        //     <hr/>
        //     <Say/>

        //     <hr/>
        //     <Toggle/>

        //     <hr/>
        //     <ChangeExample/>

        //     <hr/>
        //     <Address/>

        //     <hr/>
        //     <ListSample/>

        //     <hr/>
        //     <Product/>

        //     <hr/>
        //     <Posts/>
        //     <hr/>
        //     <Todos/>
        // </div>
        <div className="App">
            <PostList/>
        </div>
    );
}

export default App;
