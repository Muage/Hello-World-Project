import React, { useEffect, useState } from 'react'
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import Slider from 'react-slick';
import axios from 'axios';

const SlickExample = () => {
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000
    };

    const [banners, setBanners] = useState();

    const callAPI = async() => {
        const result = await axios.get('/banner/show');
        setBanners(result.data);
        // console.log('.....', banners);
    }

    useEffect(() => {
        callAPI();
    }, []);

    if(!banners) return <h1>데이터를 불러오는 중입니다...</h1>

    return (
        <Slider {...settings}>
            {banners.map((item) => (
                <div key={item.id} className='item'>
                    <h1 className='title'>{item.title}</h1>
                    <img src={item.url} alt={item.title} />
                </div>
            ))}
        </Slider>
    )
}

export default SlickExample