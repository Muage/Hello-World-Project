import React from 'react'
import { Link, Route } from 'react-router-dom';
import BannerInsert from './BannerInsert';
import BannerList from './BannerList';
import BannerRead from './BannerRead';

const BannerPage = () => {
    return (
        <div>
            <div className='menu'>
                <Link to="/banner/list">Banner List</Link>
                <Link to="/banner/insert">Banner Resister</Link>
            </div>
            <hr/>
            <Route path="/banner/insert" component={BannerInsert}/>
            <Route path="/banner/list" component={BannerList}/>
            <Route path="/banner/read/:id" component={BannerRead}/>
        </div>
    )
}

export default BannerPage