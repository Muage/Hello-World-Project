import React from 'react'
import SlickExample from './SlickExample'

const HomePage = () => {
    return (
        <div>
            <SlickExample/>
        </div>
    )
}

export default HomePage