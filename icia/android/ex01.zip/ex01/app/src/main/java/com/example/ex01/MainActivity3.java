package com.example.ex01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity3 extends AppCompatActivity {
    ArrayList<MovieVO> array = new ArrayList<>();
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        // 생성자 이용해 데이터생성
        MovieVO vo = new MovieVO(R.drawable.dragon, "드래곤길들이기", "나이트퓨리, 히컵", "크리스 샌더스");
        array.add(vo);
        vo = new MovieVO(R.drawable.a, "풀타임", "로르칼라미", "에리크 크라벨");
        array.add(vo);
        vo = new MovieVO(R.drawable.b, "녹턴", "은성호, 은건기", "정관조");
        array.add(vo);
        vo = new MovieVO(R.drawable.a, "풀타임", "로르칼라미", "에리크 크라벨");
        array.add(vo);
        vo = new MovieVO(R.drawable.b, "녹턴", "은성호, 은건기", "정관조");
        array.add(vo);
        vo = new MovieVO(R.drawable.a, "풀타임", "로르칼라미", "에리크 크라벨");
        array.add(vo);
        vo = new MovieVO(R.drawable.b, "녹턴", "은성호, 은건기", "정관조");
        array.add(vo);
        vo = new MovieVO(R.drawable.a, "풀타임", "로르칼라미", "에리크 크라벨");
        array.add(vo);
        vo = new MovieVO(R.drawable.b, "녹턴", "은성호, 은건기", "정관조");
        array.add(vo);

        // 리스트뷰 생성
        list = findViewById(R.id.list);

        // 어댑터 생성
        MovieAdapter movieAdapter = new MovieAdapter();
        list.setAdapter(movieAdapter);
    }

    // 어댑터 정의
    class MovieAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return array.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = getLayoutInflater().inflate(R.layout.item_movie, parent, false);
            MovieVO vo = array.get(position);
            ImageView image = convertView.findViewById(R.id.image);
            image.setImageResource(vo.getImage());
            TextView title = convertView.findViewById(R.id.title);
            title.setText(vo.getTitle());
            TextView actor = convertView.findViewById(R.id.actor);
            actor.setText(vo.getActor());
            TextView director = convertView.findViewById(R.id.director);
            director.setText(vo.getDirector());
            return convertView;
        }
    }
}