package com.example.ex01;

public class MovieVO {
    private int image;
    private String title;
    private String actor;
    private String director;

    public MovieVO(int image, String title, String actor, String director) {
        this.image = image;
        this.title = title;
        this.actor = actor;
        this.director = director;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    @Override
    public String toString() {
        return "MovieVO{" +
                "image='" + image + '\'' +
                ", title='" + title + '\'' +
                ", actor='" + actor + '\'' +
                ", director='" + director + '\'' +
                '}';
    }
}
