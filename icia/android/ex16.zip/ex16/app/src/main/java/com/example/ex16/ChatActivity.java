package com.example.ex16;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ChatActivity extends AppCompatActivity {
    FirebaseAuth mAuth;
    FirebaseUser user;
    FirebaseDatabase db;
    DatabaseReference ref;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    EditText content;
    List<MemoVO> array = new ArrayList<>();
    ChatAdapter adapter = new ChatAdapter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        content = findViewById(R.id.content);

        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();
        db = FirebaseDatabase.getInstance();

        getSupportActionBar().setTitle("채팅: " + user.getEmail());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        ImageView send = findViewById(R.id.send);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(content.getText().toString().equals("")) {
                    Toast.makeText(ChatActivity.this, "내용을 입력해주세요.", Toast.LENGTH_SHORT).show();
                } else {
                    MemoVO vo = new MemoVO();
                    vo.setContent(content.getText().toString());
                    vo.setDate(sdf.format(new Date()));
                    vo.setEmail(user.getEmail());

                    ref = db.getReference("chats").push();
                    vo.setKey(ref.getKey());
                    ref.setValue(vo);
                    content.setText("");
                }
            }
        });

        ref = db.getReference("chats");
        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                MemoVO vo = (MemoVO)snapshot.getValue(MemoVO.class);
                array.add(vo);
                list.scrollToPosition(array.size()-1);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    // 채팅 어댑터 정의
    class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ViewHolder> {

        @NonNull
        @Override
        public ChatAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = getLayoutInflater().inflate(R.layout.item_chat, parent, false);

            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ChatAdapter.ViewHolder holder, int position) {
            final int index = position;
            MemoVO vo = array.get(position);
            holder.content.setText(vo.getContent());
            holder.email.setText(vo.getEmail());
            holder.date.setText(vo.getDate());

            LinearLayout.LayoutParams pContent = (LinearLayout.LayoutParams)holder.content.getLayoutParams();
            LinearLayout.LayoutParams pEmail = (LinearLayout.LayoutParams)holder.email.getLayoutParams();
            LinearLayout.LayoutParams pDate = (LinearLayout.LayoutParams)holder.date.getLayoutParams();

            if(user.getEmail().equals(vo.getEmail())) {
                holder.email.setVisibility(View.INVISIBLE);
                pContent.gravity = Gravity.RIGHT;
                pEmail.gravity = Gravity.RIGHT;
                pDate.gravity = Gravity.RIGHT;
                holder.content.setBackgroundColor(Color.rgb(171, 225, 253));
            } else {
                holder.email.setVisibility(View.VISIBLE);
                pContent.gravity = Gravity.LEFT;
                pEmail.gravity = Gravity.LEFT;
                pDate.gravity = Gravity.LEFT;
            }

            holder.content.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if(user.getEmail().equals(vo.getEmail())) {
                        AlertDialog.Builder box = new AlertDialog.Builder(ChatActivity.this);
                        box.setTitle("질의");
                        box.setMessage(vo.getContent() + " 메시지를 삭제하시겠습니까?");
                        box.setPositiveButton("예", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ref = db.getReference("chats").child(vo.getKey());
                                ref.removeValue();
                                array.remove(index);
                            }
                        });
                        box.setNegativeButton("아니요", null);
                        box.show();
                    }
                    return true;
                }
            });
        }

        @Override
        public int getItemCount() {
            return array.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView content, date, email;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                content = itemView.findViewById(R.id.content);
                date = itemView.findViewById(R.id.date);
                email = itemView.findViewById(R.id.email);
            }
        }
    }
}