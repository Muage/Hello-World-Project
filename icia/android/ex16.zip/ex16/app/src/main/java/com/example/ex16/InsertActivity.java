package com.example.ex16;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class InsertActivity extends AppCompatActivity {
    FirebaseAuth mAuth;
    EditText content;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    FirebaseDatabase db;
    DatabaseReference ref;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        user = mAuth.getCurrentUser();

        String strEmail = mAuth.getCurrentUser().getEmail();

        getSupportActionBar().setTitle("메모작성: " + user.getEmail());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        content = findViewById(R.id.content);

        Button save = findViewById(R.id.save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MemoVO vo = new MemoVO();
                vo.setContent(content.getText().toString());
                if(vo.getContent().equals("")) {
                    Toast.makeText(InsertActivity.this, "내용을 입력해주세요.", Toast.LENGTH_SHORT).show();
                } else {
                    // 메모저장
                    vo.setEmail(user.getEmail());
                    vo.setDate(sdf.format(new Date()));
                    System.out.println(vo.toString());
                    ref = db.getReference("memos/" + user.getUid()).push();
                    vo.setKey(ref.getKey());
                    ref.setValue(vo);
                    Toast.makeText(InsertActivity.this, "내용이 저장되었습니다.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}