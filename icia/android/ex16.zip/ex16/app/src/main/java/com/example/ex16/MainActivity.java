package com.example.ex16;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    EditText email, password;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setTitle("로그인");

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        // 테스트 데이터
        email.setText("test03@icia.com");
        password.setText("12345678");

        mAuth = FirebaseAuth.getInstance();

        // 이메일 등록
        Button register = findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strEmail = email.getText().toString();
                String strPassword = password.getText().toString();

                AlertDialog.Builder box = new AlertDialog.Builder(MainActivity.this);

                mAuth.createUserWithEmailAndPassword(strEmail, strPassword)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()) {
                                box.setTitle("메시지");
                                box.setMessage("가입이 완료되었습니다.");
                                box.setPositiveButton("확인", null);
                                box.show();
                            } else {
                                box.setTitle("메시지");
                                box.setMessage("가입에 실패하였습니다.");
                                box.setPositiveButton("확인", null);
                                box.show();
                            }
                        }
                    });
            }
        });

        // 로그인
        Button login = findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strEmail = email.getText().toString();
                String strPassword = password.getText().toString();

                AlertDialog.Builder box = new AlertDialog.Builder(MainActivity.this);

                mAuth.signInWithEmailAndPassword(strEmail, strPassword)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()) {
                                    box.setTitle("메시지");
                                    box.setMessage("인증되었습니다.");
                                    box.setPositiveButton("확인", null);
                                    box.show();
                                    Intent intent = new Intent(MainActivity.this, ChatActivity.class);
                                    startActivity(intent);
                                } else {
                                    box.setTitle("메시지");
                                    box.setMessage("인증에 실패하였습니다.");
                                    box.setPositiveButton("확인", null);
                                    box.show();
                                }
                            }
                        });
            }
        });
    }
}