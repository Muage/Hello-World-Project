package com.icia.food;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {
    DrawerLayout drawerLayout;
    RelativeLayout mainDrawer;
    SQLiteOpenHelper helper;
    SQLiteDatabase db;

    // Fragment 생성
    Fragment foodListFragment = new FoodListFragment();
    Fragment foodMapFragment = new FoodMapFragment();
    Fragment foodKeepFragment = new FoodKeepFragment();

    FragmentTransaction transaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout = findViewById(R.id.drawerLayout);
        mainDrawer = findViewById(R.id.main_drawer);

        transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.main_content, foodListFragment).commit();

        // 데이터베이스 생성
//        helper = new FoodDB(this);
//        db = helper.getWritableDatabase();

        // 데이터베이스 테스트
//        String sql = "select * from tbl_food order by _id desc";
//        cursor = db.rawQuery(sql, null);
//        System.out.println("..........데이터: " + cursor.getCount());

        getSupportActionBar().setTitle("맛집리스트");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);

        NavigationView navigationView = findViewById(R.id.drawer_menu);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                transaction = getSupportFragmentManager().beginTransaction();

                switch(item.getItemId()) {
                    case R.id.nav_profile:
                        Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                        startActivity(intent);
                        break;

                    case R.id.nav_list: // 맛집리스트
                        transaction.replace(R.id.main_content, foodListFragment);
                        getSupportActionBar().setTitle("맛집리스트");
                        break;

                    case R.id.nav_map: // 지도리스트
                        transaction.replace(R.id.main_content, foodMapFragment);
                        getSupportActionBar().setTitle("지도리스트");
                        break;

                    case R.id.nav_keep: // 즐겨찾기리스트
                        transaction.replace(R.id.main_content, foodKeepFragment);
                        getSupportActionBar().setTitle("즐겨찾기리스트");
                        break;

                    case R.id.nav_register: // 맛집등록
                        intent = new Intent(MainActivity.this, RegisterActivity.class);
                        startActivity(intent);
                        break;
                }
                transaction.commit();
                drawerLayout.closeDrawer(mainDrawer);
                return true;
            }
        });

        onRestart();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home:
                if(drawerLayout.isDrawerOpen(mainDrawer)) {
                    drawerLayout.closeDrawer(mainDrawer);
                } else {
                    drawerLayout.openDrawer(mainDrawer);
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onRestart() {
        super.onRestart();

        TextView name = findViewById(R.id.profile_name);

        SharedPreferences preferences = getSharedPreferences("profile", AppCompatActivity.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        name.setText(preferences.getString("name", "무기명"));

        String strImage = preferences.getString("image", "");
        if(!strImage.equals("")) {
            CircleImageView icon = findViewById(R.id.profile_icon);
            icon.setImageBitmap(BitmapFactory.decodeFile(strImage));
        }

        transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.main_content, foodListFragment).commit();

//        System.out.println("***onrestart***");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode) {
            case 100:
                foodKeepFragment = new FoodKeepFragment();
                transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.main_content, foodKeepFragment).commit();
                break;

            case 200:
                System.out.println("FoodList..........");
                foodListFragment = new FoodListFragment();
                transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.main_content, foodListFragment).commit();
                break;
        }
    }

    public void mClick(View v) {
        Intent intent = null;
        switch(v.getId()) {
            case R.id.profile_icon:
                intent = new Intent(this, ProfileIconActivity.class);

                break;

            case R.id.profile_name:
                intent = new Intent(this, ProfileActivity.class);

                break;
        }
        startActivity(intent);
    }
}