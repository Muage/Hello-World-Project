package com.icia.food;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class FoodInfoActivity extends AppCompatActivity implements OnMapReadyCallback {
    FoodVO vo = new FoodVO();
    FoodDAO dao = new FoodDAO();
    ImageView image, keep;
    TextView name, tel, description, address;
    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_info);

        getSupportActionBar().setTitle("음식정보");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        image = findViewById(R.id.image);
        name = findViewById(R.id.name);
        keep = findViewById(R.id.keep);
        tel = findViewById(R.id.tel);
        description = findViewById(R.id.description);
        address = findViewById(R.id.address);

        Intent intent = getIntent();
        FoodDB helper = new FoodDB(this);
        vo = dao.read(helper, intent.getIntExtra("id", 0));

        String sdPath = Environment.getExternalStorageDirectory().getAbsolutePath();
        String strImage = sdPath + "/pictures/" + vo.getImage();
        image.setImageBitmap(BitmapFactory.decodeFile(strImage));
        name.setText(vo.getName());
        if(vo.getKeep() == 1) {
            keep.setImageResource(R.drawable.ic_keep_on);
        } else {
            keep.setImageResource(R.drawable.ic_keep_off);
        }
        tel.setText(vo.getTel());

        // 전화번호 클릭
        tel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + tel.getText().toString()));
                startActivity(callIntent);
            }
        });

        description.setText(vo.getDescription());
        address.setText(vo.getAddress());

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // 즐겨찾기 버튼 클릭
        ImageView keep = findViewById(R.id.keep);

        AlertDialog.Builder box = new AlertDialog.Builder(this);
        box.setTitle("질의");

        keep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(vo.getKeep() == 1) {
                    keep.setImageResource(R.drawable.ic_keep_on);
                    box.setMessage("즐겨찾기를 취소하시겠습니까?");
                    box.setPositiveButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dao.updateKeep(helper, 0, vo.getId());
                            keep.setImageResource(R.drawable.ic_keep_off);
                            vo.setKeep(0);
                        }
                    });
                    box.setNegativeButton("아니요", null);
                    box.show();
                } else {
                    keep.setImageResource(R.drawable.ic_keep_off);
                    box.setMessage("즐겨찾기에 등록하시겠습니까?");
                    box.setPositiveButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dao.updateKeep(helper, 1, vo.getId());
                            keep.setImageResource(R.drawable.ic_keep_on);
                            vo.setKeep(1);
                        }
                    });
                    box.setNegativeButton("아니요", null);
                    box.show();
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        LatLng latLng = new LatLng(vo.getLatitude(), vo.getLongitude());
        mMap.addMarker(new MarkerOptions().position(latLng).title(vo.getName()));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16));
    }
}