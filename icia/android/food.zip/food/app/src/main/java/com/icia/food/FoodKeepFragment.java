package com.icia.food;

import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.google.android.material.datepicker.MaterialDatePicker;

import java.util.ArrayList;

public class FoodKeepFragment extends Fragment {
    FoodDAO dao = new FoodDAO();
    ArrayList<FoodVO> array = new ArrayList<>();
    FoodAdapter adapter;
    RecyclerView list;
    StaggeredGridLayoutManager manager;
    int type = 1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_food_list, container, false);

        // 데이터 생성
        FoodDB helper = new FoodDB(getContext());
        array = dao.keepList(helper);
        System.out.println("..........데이터수: " + array.size());

        list = view.findViewById(R.id.list_food);
        manager = new StaggeredGridLayoutManager(type, StaggeredGridLayoutManager.VERTICAL);
        list.setLayoutManager(manager);
        adapter = new FoodAdapter(getContext(), array, "keep");
        list.setAdapter(adapter);

        // 타입 변경 버튼 클릭
        ImageView list_type = view.findViewById(R.id.list_type);
        list_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(type == 1) {
                    type = 2;
                    list_type.setImageResource(R.drawable.ic_list2);
                } else {
                    type = 1;
                    list_type.setImageResource(R.drawable.ic_list);
                }
                manager = new StaggeredGridLayoutManager(type, StaggeredGridLayoutManager.VERTICAL);
                list.setLayoutManager(manager);
            }
        });
        return view;
    }
}