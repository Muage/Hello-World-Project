package com.example.ex07;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {
    AddressDB helper;
    SQLiteDatabase db;
    String sqlAll = "select * from address order by _id desc";
    Cursor cursor;
    Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        helper = new AddressDB(this);
        db = helper.getWritableDatabase();
        cursor = db.rawQuery(sqlAll, null);
        System.out.println(".........." + cursor.getCount());
        while(cursor.moveToNext()) {
            System.out.println("----------------------------------------");
            System.out.print(cursor.getString(1) + "   ");
            System.out.print(cursor.getString(2) + "   ");
            System.out.print(cursor.getString(3));
            System.out.println("");
        }

        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_home);

        checkPermission();

        FloatingActionButton add = findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, InsertActivity.class);
                startActivity(intent);
            }
        });

        adapter = new Adapter(this, cursor);
        ListView list = findViewById(R.id.list);
        list.setAdapter(adapter);
        registerForContextMenu(list);
    }

    public void checkPermission() {
        String[] permissions = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
        };
        ArrayList<String> noPermissions=new ArrayList<>();
        for(String permission:permissions) {
            if(ActivityCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                noPermissions.add(permission);
            }
            if(noPermissions.size() > 0) {
                String[] reqPermissions = noPermissions.toArray(new String[noPermissions.size()]);
                ActivityCompat.requestPermissions(this, reqPermissions, 100);
            }
        }
    }

    class Adapter extends CursorAdapter {

        public Adapter(Context context, Cursor c) {
            super(context, c);
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.item, parent, false);
            return view;
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            String strImage = cursor.getString(3);
            String strName = cursor.getString(1);
            String strTel = cursor.getString(2);
            CircleImageView image = view.findViewById(R.id.image);
            image.setImageBitmap(BitmapFactory.decodeFile(strImage));
            TextView name = view.findViewById(R.id.name);
            name.setText(strName);
            TextView tel = view.findViewById(R.id.tel);
            tel.setText(strTel);
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        cursor = db.rawQuery(sqlAll, null);
        adapter.changeCursor(cursor);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        int id = cursor.getInt(0);
        String name = cursor.getString(1);
        menu.setHeaderTitle(name + " 메뉴선택");
        menu.add(0, 1, 0, "수정");
        menu.add(0, 2, 0, "삭제");
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        final int id = cursor.getInt(0);
        switch(item.getItemId()) {
            case 1: // 수정
                Intent intent = new Intent(this, ReadActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
                break;

            case 2: // 삭제
                AlertDialog.Builder box = new AlertDialog.Builder(this);
                box.setTitle("질의");
                box.setMessage(id + "번 데이터를 삭제하시겠습니까?");
                box.setPositiveButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String sql = "delete from address where _id = " + id;
                        db.execSQL(sql);
                        onRestart();
                    }
                });
                box.setNegativeButton("아니요", null);
                box.show();
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        MenuItem search = menu.findItem(R.id.search);
        SearchView searchView = (SearchView)search.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                String word = "'%" + newText + "%'";
                String sql = "select * from address where name like " + word + " or tel like " + word;
                cursor = db.rawQuery(sql, null);
                adapter.changeCursor(cursor);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }
}