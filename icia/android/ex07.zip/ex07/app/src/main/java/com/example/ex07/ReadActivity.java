package com.example.ex07;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import de.hdodenhof.circleimageview.CircleImageView;

public class ReadActivity extends AppCompatActivity {
    AddressDB helper;
    SQLiteDatabase db;
    EditText name, tel;
    String strImage = "";
    CircleImageView image;
    int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        getSupportActionBar().setTitle("주소수정");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Button save = findViewById(R.id.save);
        save.setText("수정하기");
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder box = new AlertDialog.Builder(ReadActivity.this);
                box.setTitle("질의");
                box.setMessage("수정하시겠습니까?");
                box.setPositiveButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String strName = name.getText().toString();
                        String strTel = tel.getText().toString();
                        if(strName.equals("") || strTel.equals("") || strImage.equals("")) {
                            Toast.makeText(ReadActivity.this, "내용을 모두 입력해주세요.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        String sql = "update address set name = '" + strName + "', tel = '" + strTel + "', image = '" + strImage + "' where _id = " + id;

                        db.execSQL(sql);
                        finish();
                    }
                });
                box.setNegativeButton("아니요", null);
                box.show();
            }
        });

        Intent intent = getIntent();
        id = intent.getIntExtra("id", 0);

        helper = new AddressDB(this);
        db = helper.getWritableDatabase();
        String sql = "select * from address where _id = " + id;
        Cursor cursor = db.rawQuery(sql, null);

        name = findViewById(R.id.name);
        tel = findViewById(R.id.tel);
        image = findViewById(R.id.image);
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 0);
            }
        });

        if(cursor.moveToNext()) {
            name.setText(cursor.getString(1));
            tel.setText(cursor.getString(2));
            strImage = cursor.getString(3);
            image.setImageBitmap(BitmapFactory.decodeFile(strImage));
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        finish();
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        image.setImageURI(data.getData());

        Cursor cursor = getContentResolver().query(data.getData(), null, null, null, null);
        if(cursor.moveToFirst()) {
            strImage = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
            System.out.println("......" + strImage);
        }
    }
}