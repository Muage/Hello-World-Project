package com.example.ex05;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MemoDB extends SQLiteOpenHelper {
    public MemoDB(@Nullable Context context) {
        super(context, "memo.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table memo (_id integer primary key autoincrement, content text, date text)");
        db.execSQL("insert into memo(content, date) values('안드로이드', '2022-08-20 12:20:22')");
        db.execSQL("insert into memo(content, date) values('JSP & Servlet', '2022-08-17 11:20:22')");
        db.execSQL("insert into memo(content, date) values('Node.js', '2022-07-28 10:20:22')");
        db.execSQL("insert into memo(content, date) values('HTML5', '2022-07-18 08:20:22')");
        db.execSQL("insert into memo(content, date) values('Database', '2022-07-11 12:20:22')");
        db.execSQL("insert into memo(content, date) values('JAVA', '2022-06-15 09:25:22')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
