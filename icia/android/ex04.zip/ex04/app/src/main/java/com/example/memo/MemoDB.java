package com.example.memo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MemoDB extends SQLiteOpenHelper {
    public MemoDB(@Nullable Context context) {
        super(context, "mome.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table memo(_id integer primary key autoincrement, content text, date text);");
        db.execSQL("insert into memo(content, date) values('Android 스튜디오 설치', '2022-08-10 12:10:10')");
        db.execSQL("insert into memo(content, date) values('Android 스튜디오로 이전', '2022-08-12 12:10:10')");
        db.execSQL("insert into memo(content, date) values('Android 스튜디오 구성', '2022-08-15 12:10:10')");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
