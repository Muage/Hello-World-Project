package com.example.ex02;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    ArrayList<MovieVO> array = new ArrayList<>();
    ListView list;

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        getSupportActionBar().setTitle("연습2");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Setter 이용해 데이터생성
        MovieVO vo = new MovieVO();
        vo.setImage(R.drawable.dragon);
        vo.setTitle("드래곤길들이기");
        vo.setActor("히컵, 나이트퓨리");
        array.add(vo);

        vo = new MovieVO();
        vo.setImage(R.drawable.zootopia);
        vo.setTitle("주토피아");
        vo.setActor("주디홉스, 닉와일드");
        array.add(vo);

        vo = new MovieVO();
        vo.setImage(R.drawable.pets);
        vo.setTitle("마이펫의이중생활");
        vo.setActor("스노우볼, 맥스");
        array.add(vo);

        vo = new MovieVO();
        vo.setImage(R.drawable.chihiro);
        vo.setTitle("센과치히로의행방불명");
        vo.setActor("센, 하쿠");
        array.add(vo);

        vo = new MovieVO();
        vo.setImage(R.drawable.stimme);
        vo.setTitle("귀를기울이면");
        vo.setActor("타카시 잇세이, 브리트니 스노");
        array.add(vo);

        // 리스트뷰 생성
        list = findViewById(R.id.list);

        // 어댑터 생성
        MovieAdapter adapter = new MovieAdapter();
        list.setAdapter(adapter);
    }
    // 어댑터 정의
    class MovieAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return array.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = getLayoutInflater().inflate(R.layout.item_movie, parent, false);

            MovieVO vo = array.get(position);

            ImageView image = convertView.findViewById(R.id.image);
            image.setImageResource(vo.getImage());

            TextView title = convertView.findViewById(R.id.title);
            title.setText(vo.getTitle());

            TextView actor = convertView.findViewById(R.id.actor);
            actor.setText(vo.getActor());

            return convertView;
        }
    }
}