package com.example.ex15;

import static com.example.ex15.RemoteService.BASE_URL;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class InsertActivity extends AppCompatActivity implements OnMapReadyCallback {
    double x, y;
    GoogleMap mMap;
    EditText name, tel, address;
    Retrofit retrofit;
    RemoteService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read);

        name = findViewById(R.id.name);
        tel = findViewById(R.id.tel);
        address = findViewById(R.id.address);

        getSupportActionBar().setTitle("맛집등록");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(InsertActivity.this);

        Intent intent = getIntent();
        x = intent.getDoubleExtra("x", 0);
        y = intent.getDoubleExtra("y", 0);
        System.out.println("x: " + x);
        System.out.println("y: " + y);

        Button insert = findViewById(R.id.insert);
        insert.setVisibility(View.VISIBLE);

        retrofit = new Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();
        service = retrofit.create(RemoteService.class);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FoodVO vo = new FoodVO();
                vo.setName(name.getText().toString());
                vo.setTel(tel.getText().toString());
                vo.setAddress(address.getText().toString());
                vo.setX(x);
                vo.setY(y);
                AlertDialog.Builder box = new AlertDialog.Builder(InsertActivity.this);
                box.setTitle("질의");
                box.setMessage("맛집을 등록하시겠습니까?");
                box.setPositiveButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Call<Void> call = service.insert(vo);
                        call.enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                Intent intent1 = new Intent(InsertActivity.this, MainActivity.class);
                                startActivity(intent1);
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {

                            }
                        });
                    }
                });
                box.setNegativeButton("아니요", null);
                box.show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        // 해당 음식점 위치로 이동
        System.out.println("x: " + x);
        System.out.println("y: " + y);
        mMap = googleMap;
        LatLng latLng = new LatLng(y, x);
        mMap.addMarker(new MarkerOptions().position(latLng));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16));
    }
}