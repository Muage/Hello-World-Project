package com.example.ex08;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.SearchView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;

public class BookActivity extends AppCompatActivity {
    String url = "https://openapi.naver.com/v1/search/book.json";
    String query = "안드로이드";
    JSONArray array = new JSONArray();
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setTitle("도서검색");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_book);

        list = findViewById(R.id.list);

        new NaverThread().execute();
    }

    class NaverThread extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... strings) {
            String result = NaverAPI.search(query, url);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                array = new JSONObject(s).getJSONArray("items");
                BookAdapter bookAdapter = new BookAdapter();
                list.setAdapter(bookAdapter);
            } catch (Exception e) {
                System.out.println("오류: " + e.toString());
            }
        }
    }

    class BookAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return array.length();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.item, parent, false);
            RatingBar rating = view.findViewById(R.id.rating);
            rating.setVisibility(View.INVISIBLE);

            try {
                JSONObject obj = (JSONObject)array.get(position);
                String strImage = obj.getString("image");
                String strTitle = obj.getString("title");
                String strAuthor = obj.getString("author");
                String strPublisher = obj.getString("publisher");
                DecimalFormat df = new DecimalFormat("#,###원");
                String strDiscount = df.format(obj.getInt("discount"));

                ImageView image = view.findViewById(R.id.image);
                TextView title = view.findViewById(R.id.title);
                TextView author = view.findViewById(R.id.director);
                TextView publisher = view.findViewById(R.id.actor);
                TextView discount = view.findViewById(R.id.pubDate);

                System.out.println(".........." + obj);
                if(!strImage.equals("")) {
                    Picasso.with(BookActivity.this).load(strImage).into(image);
                }
                title.setText(Html.fromHtml(strTitle));
                author.setText(Html.fromHtml(strAuthor));
                publisher.setText(Html.fromHtml(strPublisher));
                discount.setText(Html.fromHtml(strDiscount));

                final String strLink = obj.getString("link");
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(BookActivity.this, LinkActivity.class);
                        intent.putExtra("link", strLink);
                        startActivity(intent);
                    }
                });
            } catch (Exception e) {
                System.out.println("오류: " + e.toString());
            }
            return view;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        MenuItem search = menu.findItem(R.id.search);
        SearchView searchView = (SearchView)search.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                query = newText;
                new BookActivity.NaverThread().execute();
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case R.id.movie:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}