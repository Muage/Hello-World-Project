package com.example.ex08;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.SearchView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    JSONArray array = new JSONArray();
    Adapter adapter;
    ListView list;
    String query = "미니언즈";
    String url = "https://openapi.naver.com/v1/search/movie.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_home);

        new NaverThread().execute();    // 데이터 생성
        list = findViewById(R.id.list);
    }

    class NaverThread extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... strings) {
            String result = NaverAPI.search(query, url);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                array = new JSONObject(s).getJSONArray("items");
////                System.out.println("사이즈: " + array.length());
                adapter = new Adapter();
                list.setAdapter(adapter);
            } catch (Exception e) {
                System.out.println("오류: " + e.toString());
            }
        }
    }

    class Adapter extends BaseAdapter {
        @Override
        public int getCount() {
            return array.length();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.item, parent, false);
            try {
                JSONObject obj = (JSONObject)array.get(position);
                String strImage = obj.getString("image");
                String strTitle = obj.getString("title");
                String strDirector = obj.getString("director");
                String strActor = obj.getString("actor");
                String strPubDate = obj.getString("pubDate");
                String strRating = obj.getString("userRating");
                float fltRating = Float.parseFloat(strRating);

                ImageView image = view.findViewById(R.id.image);
//                System.out.println(".........." + strImage);
                if(!strImage.equals("")) {
                    Picasso.with(MainActivity.this).load(strImage).into(image);
                }
                TextView title = view.findViewById(R.id.title);
                title.setText(Html.fromHtml(strTitle));
                TextView director = view.findViewById(R.id.director);
                director.setText(Html.fromHtml(strDirector));
                TextView actor = view.findViewById(R.id.actor);
                actor.setText(Html.fromHtml(strActor));
                TextView pubDate = view.findViewById(R.id.pubDate);
                pubDate.setText(Html.fromHtml(strPubDate));
                RatingBar rating = view.findViewById(R.id.rating);
                rating.setRating(fltRating);

                final String strLink = obj.getString("link");
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(MainActivity.this, LinkActivity.class);
                        intent.putExtra("link", strLink);
                        startActivity(intent);
                    }
                });
            } catch (Exception e) {
                System.out.println("오류: " + e.toString());
            }
            return view;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        MenuItem search = menu.findItem(R.id.search);
        SearchView searchView = (SearchView)search.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                query = newText;
                new NaverThread().execute();
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case R.id.book:
                Intent intent = new Intent(this, BookActivity.class);
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}