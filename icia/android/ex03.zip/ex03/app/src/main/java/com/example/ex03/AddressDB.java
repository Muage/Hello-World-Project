package com.example.ex03;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class AddressDB extends SQLiteOpenHelper {
    public AddressDB(@Nullable Context context) {
        super(context, "address.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String str = "create table address(_id integer primary key autoincrement, name text, tel text, juso text);";
        db.execSQL(str);
        str = "insert into address(name, tel, juso) values('홍길동', '010-0000-1111', '인천시 미추홀구 문학동');";
        db.execSQL(str);
        str = "insert into address(name, tel, juso) values('심청이', '010-2222-3333', '서울시 송파구 잠실동');";
        db.execSQL(str);
        str = "insert into address(name, tel, juso) values('강감찬', '010-4444-5555', '서울시 구로구 고척동');";
        db.execSQL(str);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
