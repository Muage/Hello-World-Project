package com.example.ex13;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface RemoteService {
    public static final String BASE_URL = "http://192.168.0.194:3000";

    // 사용자목록
    @GET("/users/list.json")
    Call<List<UserVO>> list();

    // 사용자등록
    @POST("/users/insert")
    Call<Void> insert(@Body UserVO vo);

    // 사용자정보 Read
    @GET("/users/read.json")
    Call<UserVO> read(@Query("id") String id);

    // 사용자수정
    @POST("/users/update")
    Call<Void> update(@Body UserVO vo);

    // 사용자삭제
    @POST("/users/delete")
    Call<Void> delete(@Body UserVO id);
}
