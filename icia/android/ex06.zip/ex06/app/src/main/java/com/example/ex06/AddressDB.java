package com.example.ex06;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class AddressDB extends SQLiteOpenHelper {

    public AddressDB(@Nullable Context context) {
        super(context, "address.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table address(_id integer primary key autoincrement, name text, tel text, juso text, image text)");
        db.execSQL("insert into address(name, tel, juso) values('홍길동', '010-0000-1111', '인천시 미추홀구 문학동')");
        db.execSQL("insert into address(name, tel, juso) values('심청이', '010-2222-3333', '서울시 송파구 잠실동')");
        db.execSQL("insert into address(name, tel, juso) values('강감찬', '010-4444-5555', '서울시 구로구 고척동')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
