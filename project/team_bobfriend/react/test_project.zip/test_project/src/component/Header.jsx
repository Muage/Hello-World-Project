import React from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap'
import { withRouter } from 'react-router-dom';

const Header = ({ history }) => {
    const s_code = "s1";
    
    const onClick = (e) => {
        e.preventDefault();

        const href = e.target.getAttribute("href");
        history.push(href);
    }

    return (
        <Navbar className="mb-3" bg="primary" variant="dark">
            <Container>
                <Navbar.Brand href="#home" onClick={onClick}>Admin</Navbar.Brand>
                <Nav className="me-auto">
                    <Nav.Link
                        href='/user'
                        onClick={onClick}>User
                    </Nav.Link>
                    <Nav.Link
                        href='/store/list'
                        onClick={onClick}>Store
                    </Nav.Link>
                    <Nav.Link
                        href={`/menu/list/${s_code}`}
                        onClick={onClick}>Menu
                    </Nav.Link>
                </Nav>
            </Container>
        </Navbar>
    )
}

export default withRouter(Header)