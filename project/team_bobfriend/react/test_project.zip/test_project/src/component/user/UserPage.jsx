import React from 'react'

const UserPage = () => {
    return (
        <div>UserPage</div>
    )
}

export default UserPage