import React from 'react'
import { Button, Dropdown, DropdownButton, Form, InputGroup } from 'react-bootstrap'
import { AiOutlineSearch } from 'react-icons/ai'

const SearchBar = () => {

    return (
        <div>
            <InputGroup className="m-3" style={{width: "50%", float: "right"}}>
                <DropdownButton
                        variant="outline-secondary"
                        title="Code">
                    <Dropdown.Item href="#">Code</Dropdown.Item>
                    <Dropdown.Item href="#">Category</Dropdown.Item>
                    <Dropdown.Item href="#">Name</Dropdown.Item>
                    <Dropdown.Item href="#">Location</Dropdown.Item>
                    <Dropdown.Item href="#">Tel</Dropdown.Item>
                    <Dropdown.Item href="#">Admin</Dropdown.Item>
                </DropdownButton>
                <Form.Control type="text"/>
                <Button variant="secondary">
                    <AiOutlineSearch style={{fontSize: "1.3rem"}}/>
                </Button>
            </InputGroup>
        </div>
    )
}

export default SearchBar