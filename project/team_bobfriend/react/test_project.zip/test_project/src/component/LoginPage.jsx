import React from 'react'
import { Button, Card, Form, Nav, Row } from 'react-bootstrap'

const LoginPage = () => {
    return (
        <>
		<Row className="justify-content-md-center">
            <h2 style={{marginTop: "50px", textAlign: "center"}}>Sign in to here</h2>
            <Card className="my-3" style={{ width: '40%' }}>
                <Row className="justify-content-md-center">
                <Form className="my-4" style={{width: '90%', textAlign: "left"}}>
                    <Form.Group className="mb-3">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" placeholder="Enter email" />
                        <Form.Text className="text-muted">
                            We'll never share your email with anyone else.
                        </Form.Text>
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>Password</Form.Label>
                        <Form.Control type="password" placeholder="Password" />
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Check type="checkbox" label="Check me out" />
                    </Form.Group>
                    <Button style={{ width: "100%" }} variant="primary" type="submit">
                        Sign in
                    </Button>
                </Form>
                </Row>
            </Card>
		</Row>
		<Row className="justify-content-md-center">
			<Card className="p-3" style={{width: '40%', textAlign: "center"}}>
				<Nav.Link style={{color: "rgb(13, 110, 253)"}}>Create an account.</Nav.Link>
			</Card>
		</Row>
		</>
    )
}

export default LoginPage