import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './component/Header';
import LoginPage from './component/LoginPage';
import { Route, Switch } from 'react-router-dom';
import UserPage from './component/user/UserPage';
import StorePage from './component/store/StorePage';

function App() {
	return (
		<div className="App">
			{/* <LoginPage/> */}
			<Header/>

			<Switch>
				<Route path='/user' component={UserPage}/>
				<Route path='/store' component={StorePage}/>
			</Switch>
		</div>
	);
}

export default App;
