import React from 'react'
import { Nav } from 'react-bootstrap'
import { Route } from 'react-router-dom';
import MenuInsert from './MenuInsert';
import MenuList from './MenuList';
import MenuRead from './MenuRead';

const MenuPage = ({ history }) => {
    const s_code = "s1";

    const onClick = (e) => {
        e.preventDefault();

        const href = e.target.getAttribute("href");
        history.push(href);
    }

    return (
        <div>
            {/* <Nav fill variant="tabs" defaultActiveKey={`/menu/list/${s_code}`}>
                <Nav.Item>
                    <Nav.Link
                        href={`/menu/list/${s_code}`}
                        onClick={onClick}>메뉴목록
                    </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                    <Nav.Link
                        href='/menu/insert'
                        onClick={onClick}>메뉴등록
                    </Nav.Link>
                </Nav.Item>
            </Nav> */}

            <Route path={`/menu/list/${s_code}`} component={MenuList}/>
            <Route path='/menu/insert' component={MenuInsert}/>
            <Route path={`/menu/read/:s_code/:m_code`} component={MenuRead}/>
        </div>
    )
}

export default MenuPage