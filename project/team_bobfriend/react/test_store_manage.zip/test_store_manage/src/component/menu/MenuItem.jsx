import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Figure } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const MenuItem = ({ menu, callMenus }) => {
    const {m_code, s_code, m_name, m_price, m_photo} = menu;

    const [image, setImage] = useState("");

    const onClickDelete = async() => {
        if(!window.confirm(`${m_name} 메뉴를 삭제하시겠습니까?`)) return;

        await axios.post('/api/menu/delete', menu);
        alert(`${m_name} 메뉴가 삭제되었습니다.`);
        callMenus();
    }

    useEffect(() => {
        callMenus();
        // console.log(menu);

        if(m_photo) setImage(`/api/display?fileName=${m_photo}`)
        else setImage("https://dummyimage.com/100")
    }, [])

    return (
        <tr>
            <td>
                <Figure.Image
                        width={100}
                        src={image}/>
            </td>
            <td>
                <Link to={`/menu/read/${s_code}/${m_code}`}>{m_name}</Link>
            </td>
            <td>{m_price}</td>
            <td>
                <Button
                       variant="outline-danger"
                       onClick={onClickDelete}>Delete
                </Button>
            </td>
        </tr>
    )
}

export default MenuItem