import axios from 'axios'
import React, { Fragment, useEffect, useState } from 'react'
import { Button, Col, Container, Row, Table } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import MenuItem from './MenuItem'

const MenuList = () => {
    const s_code = "s1";

    const [menus, setMenus] = useState([]);

    const callMenus = async() => {
        const result = await axios.get(`/api/menu/list/${s_code}`);
        setMenus(result.data);
        // console.log(result.data);
    };

    useEffect(() => {
        callMenus();
    }, []);

    if(!menus) return <h2>Loading...</h2>

    return (
        <>
            <h1 className="my-3">Menu List</h1>
            <Row>
                <Col md={5}>
                    <Link to='/menu/insert'>
                        <Button>메뉴등록</Button>
                    </Link>
                </Col>
            </Row>
            <Table className="my-3" style={{margin: "0px auto", width: "80%"}}>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {menus.map(menu =>
                        <MenuItem
                            key={menu.m_code}
                            menu={menu}
                            callMenus={callMenus}/>
                    )}
                </tbody>
            </Table>
        </>
    )
}

export default MenuList