import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './component/Header';
import { Route, Switch } from 'react-router-dom';
import MenuPage from './component/menu/MenuPage';
import StoreRead from './component/StoreRead';

function App() {
	return (
		<div className="App">
			<Header/>

			<Switch>
				<Route path='/info' component={StoreRead}/>
				<Route path='/menu' component={MenuPage}/>
			</Switch>
		</div>
	);
}

export default App;
